package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.ShopRepository
import com.example.domain.model.CartItem
import com.example.util.CurrencyFormatter
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ShopSmartAccountingTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: ShopRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ShopRepository(db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testCurrencyFormatting() {
        assertEquals("P 150.00", CurrencyFormatter.format(150.0, "P"))
        assertEquals("P 0.50", CurrencyFormatter.format(0.50, "P"))
        assertEquals("P 1,250.75", CurrencyFormatter.format(1250.75, "P"))
    }

    @Test
    fun testWhatsAppPhoneNumberCleaning() {
        assertEquals("26771234567", WhatsAppHelper.cleanPhoneNumber("+267 71 234 567"))
        assertEquals("26772123456", WhatsAppHelper.cleanPhoneNumber("72123456"))
        assertEquals("26774000111", WhatsAppHelper.cleanPhoneNumber("26774000111"))
    }

    @Test
    fun testCartCalculationsAndDiscounts() {
        val product = ProductEntity(
            id = 1,
            name = "White Star Maize 5kg",
            buyingPrice = 40.00,
            sellingPrice = 50.00,
            quantity = 20.0
        )

        val cartItem = CartItem(product = product, quantity = 2.0, discountPercent = 10.0)
        assertEquals(100.0, cartItem.grossSubtotal, 0.001)
        assertEquals(10.0, cartItem.discountAmount, 0.001)
        assertEquals(90.0, cartItem.finalSubtotal, 0.001)
        assertEquals(80.0, cartItem.cogs, 0.001) // 2 * 40.0
    }

    @Test
    fun testSaleCheckoutDeductsStockAndUpdatesCustomerCredit() = runBlocking {
        // Insert product
        val prodId = repository.saveProduct(
            ProductEntity(
                name = "Sunfoil Cooking Oil 2L",
                buyingPrice = 30.00,
                sellingPrice = 40.00,
                quantity = 15.0
            )
        )
        val product = db.productDao().getProductById(prodId)!!

        // Insert customer
        val custId = repository.saveCustomer(
            CustomerEntity(
                name = "Kabo Molefe",
                phone = "72345678",
                totalDebt = 0.0
            )
        )
        val customer = db.customerDao().getCustomerById(custId)!!

        // Complete a split sale: 3 units = P120 total. P50 paid in Cash, P70 in Credit
        val cartItems = listOf(CartItem(product = product, quantity = 3.0))
        val result = repository.completeSale(
            cartItems = cartItems,
            discountAmount = 0.0,
            paymentMethod = "SPLIT",
            amountPaid = 50.00,
            creditAmount = 70.00,
            splitDetails = "Cash: P50, Credit: P70",
            customer = customer,
            notes = "Test sale"
        )

        assertTrue(result.isSuccess)
        val (sale, items) = result.getOrThrow()

        assertEquals(120.00, sale.totalAmount, 0.001)
        assertEquals(90.00, sale.totalCostOfGoodsSold, 0.001) // 3 * 30.00
        assertEquals(50.00, sale.amountPaid, 0.001)
        assertEquals(70.00, sale.creditAmount, 0.001)

        // Verify stock deducted: 15 - 3 = 12
        val updatedProduct = db.productDao().getProductById(prodId)!!
        assertEquals(12.0, updatedProduct.quantity, 0.001)

        // Verify customer debt updated: 0 + 70 = 70
        val updatedCustomer = db.customerDao().getCustomerById(custId)!!
        assertEquals(70.00, updatedCustomer.totalDebt, 0.001)
    }

    @Test
    fun testDebtRepaymentLogic() = runBlocking {
        val custId = repository.saveCustomer(
            CustomerEntity(
                name = "Lesego Tau",
                phone = "71234567",
                totalDebt = 100.00,
                totalPaid = 50.00
            )
        )

        // Repay partial debt: P40
        val paymentResult = repository.repayDebt(
            customerId = custId,
            amount = 40.00,
            paymentMethod = "ORANGE_MONEY",
            notes = "Orange Money Ref 12345"
        )
        assertTrue(paymentResult.isSuccess)

        val updatedCustomer = db.customerDao().getCustomerById(custId)!!
        assertEquals(60.00, updatedCustomer.totalDebt, 0.001)
        assertEquals(90.00, updatedCustomer.totalPaid, 0.001)

        // Attempting to pay P100 should be capped at remaining debt P60
        val fullPayResult = repository.repayDebt(
            customerId = custId,
            amount = 100.00,
            paymentMethod = "CASH",
            notes = "Settled in full"
        )
        assertTrue(fullPayResult.isSuccess)

        val settledCustomer = db.customerDao().getCustomerById(custId)!!
        assertEquals(0.00, settledCustomer.totalDebt, 0.001)
        assertEquals(150.00, settledCustomer.totalPaid, 0.001)
    }

    @Test
    fun testAccountingGrossAndNetProfitCalculations() = runBlocking {
        // Product 1: Cost P40, Sell P50, Qty 10
        val p1Id = repository.saveProduct(
            ProductEntity(name = "Maize 5kg", buyingPrice = 40.0, sellingPrice = 50.0, quantity = 10.0)
        )
        val p1 = db.productDao().getProductById(p1Id)!!

        // Sale: 2 units = Revenue P100, COGS P80 -> Gross Profit = P20
        repository.completeSale(
            cartItems = listOf(CartItem(product = p1, quantity = 2.0)),
            discountAmount = 0.0,
            paymentMethod = "CASH",
            amountPaid = 100.0,
            creditAmount = 0.0,
            splitDetails = "",
            customer = null,
            notes = ""
        )

        // Record an expense: Electricity P5.00
        repository.saveExpense(
            ExpenseEntity(
                category = "Electricity",
                amount = 5.00,
                paymentMethod = "CASH",
                description = "BPC Token"
            )
        )

        val report = repository.calculateFinancialReport(0L, Long.MAX_VALUE)

        assertEquals(100.00, report.salesRevenue, 0.001)
        assertEquals(80.00, report.costOfGoodsSold, 0.001)
        assertEquals(20.00, report.grossProfit, 0.001) // 100 - 80
        assertEquals(5.00, report.operatingExpenses, 0.001)
        assertEquals(15.00, report.netOperatingProfit, 0.001) // 20 - 5
    }

    @Test
    fun testSaleCancellationRestoresInventoryAndCredit() = runBlocking {
        val prodId = repository.saveProduct(
            ProductEntity(name = "Bread", buyingPrice = 8.0, sellingPrice = 12.0, quantity = 10.0)
        )
        val custId = repository.saveCustomer(
            CustomerEntity(name = "Neo", phone = "74567890", totalDebt = 0.0)
        )

        val saleRes = repository.completeSale(
            cartItems = listOf(CartItem(product = db.productDao().getProductById(prodId)!!, quantity = 2.0)),
            discountAmount = 0.0,
            paymentMethod = "CREDIT",
            amountPaid = 0.0,
            creditAmount = 24.0,
            splitDetails = "",
            customer = db.customerDao().getCustomerById(custId)!!,
            notes = ""
        )
        val saleId = saleRes.getOrThrow().first.id

        assertEquals(8.0, db.productDao().getProductById(prodId)!!.quantity, 0.001)
        assertEquals(24.0, db.customerDao().getCustomerById(custId)!!.totalDebt, 0.001)

        // Cancel sale
        val cancelRes = repository.cancelSale(saleId, "Customer returned")
        assertTrue(cancelRes.isSuccess)

        // Stock restored back to 10
        assertEquals(10.0, db.productDao().getProductById(prodId)!!.quantity, 0.001)
        // Customer debt reversed back to 0
        assertEquals(0.0, db.customerDao().getCustomerById(custId)!!.totalDebt, 0.001)
    }

    @Test
    fun testBackupAndRestore() = runBlocking {
        repository.saveProduct(ProductEntity(name = "Test Item", buyingPrice = 10.0, sellingPrice = 15.0, quantity = 5.0))
        val json = repository.exportBackupJson()
        assertTrue(json.contains("Test Item"))

        val restoreRes = repository.importBackupJson(json)
        assertTrue(restoreRes.isSuccess)
    }
}
