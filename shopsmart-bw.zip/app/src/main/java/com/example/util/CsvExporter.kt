package com.example.util

import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun exportProductsToCsv(products: List<ProductEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Name,Barcode_SKU,Category,Cost_Price_BWP,Selling_Price_BWP,Quantity,Unit,Min_Stock\n")
        products.forEach { p ->
            sb.append("${p.id},\"${p.name.replace("\"", "\"\"")}\",\"${p.skuOrBarcode}\",\"${p.category}\",${p.buyingPrice},${p.sellingPrice},${p.quantity},\"${p.unit}\",${p.minStockLevel}\n")
        }
        return sb.toString()
    }

    fun exportSalesToCsv(sales: List<SaleEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Receipt_Number,Date,Subtotal_BWP,Discount_BWP,Total_Revenue_BWP,COGS_BWP,Amount_Paid_BWP,Credit_BWP,Payment_Method,Customer_Name,Customer_Phone,Status\n")
        sales.forEach { s ->
            val dateStr = dateFormat.format(Date(s.timestamp))
            sb.append("${s.id},\"${s.receiptNumber}\",\"$dateStr\",${s.subtotal},${s.discountAmount},${s.totalAmount},${s.totalCostOfGoodsSold},${s.amountPaid},${s.creditAmount},\"${s.paymentMethod}\",\"${s.customerName ?: ""}\",\"${s.customerPhone ?: ""}\",\"${s.status}\"\n")
        }
        return sb.toString()
    }

    fun exportCustomersToCsv(customers: List<CustomerEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Name,Phone,Outstanding_Debt_BWP,Total_Paid_BWP,Notes\n")
        customers.forEach { c ->
            sb.append("${c.id},\"${c.name.replace("\"", "\"\"")}\",\"${c.phone}\",${c.totalDebt},${c.totalPaid},\"${c.notes.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }

    fun exportExpensesToCsv(expenses: List<ExpenseEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Date,Category,Amount_BWP,Payment_Method,Description,Supplier_Recipient,Is_Reversed\n")
        expenses.forEach { e ->
            val dateStr = dateFormat.format(Date(e.date))
            sb.append("${e.id},\"$dateStr\",\"${e.category}\",${e.amount},\"${e.paymentMethod}\",\"${e.description.replace("\"", "\"\"")}\",\"${e.supplierOrRecipient.replace("\"", "\"\"")}\",${e.isReversed}\n")
        }
        return sb.toString()
    }
}
