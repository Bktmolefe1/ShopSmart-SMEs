package com.example.util

import java.util.Locale

object CurrencyFormatter {
    const val DEFAULT_CURRENCY = "P"

    fun format(amount: Double, symbol: String = DEFAULT_CURRENCY): String {
        return String.format(Locale.US, "%s %,.2f", symbol, amount)
    }

    fun parseAmount(text: String): Double {
        val clean = text.replace("[^0-9.]".toRegex(), "")
        return clean.toDoubleOrNull() ?: 0.0
    }
}
