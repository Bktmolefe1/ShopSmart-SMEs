package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WhatsAppHelper {

    fun formatReceiptMessage(
        settings: ShopSettingsEntity,
        sale: SaleEntity,
        items: List<SaleItemEntity>
    ): String {
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US)
        val dateStr = dateFormat.format(Date(sale.timestamp))
        val currency = settings.currencySymbol

        val sb = StringBuilder()
        sb.append("🧾 *${settings.businessName.uppercase()}*\n")
        if (settings.address.isNotBlank()) sb.append("${settings.address}\n")
        if (settings.phone.isNotBlank()) sb.append("Tel: ${settings.phone}\n")
        sb.append("--------------------------------\n")
        sb.append("*RECEIPT:* ${sale.receiptNumber}\n")
        sb.append("*Date:* $dateStr\n")
        if (!sale.customerName.isNullOrBlank()) {
            sb.append("*Customer:* ${sale.customerName}")
            if (!sale.customerPhone.isNullOrBlank()) {
                sb.append(" (${sale.customerPhone})")
            }
            sb.append("\n")
        }
        sb.append("--------------------------------\n")
        sb.append("*ITEMS:*\n")

        items.forEach { item ->
            val qtyStr = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else String.format(Locale.US, "%.2f", item.quantity)
            sb.append("• ${item.productName}\n")
            sb.append("   $qtyStr ${item.unit} x $currency ${String.format(Locale.US, "%.2f", item.unitSellingPrice)} = *$currency ${String.format(Locale.US, "%.2f", item.subtotal)}*\n")
        }

        sb.append("--------------------------------\n")
        sb.append("Subtotal: $currency ${String.format(Locale.US, "%.2f", sale.subtotal)}\n")
        if (sale.discountAmount > 0.0) {
            sb.append("Discount: -$currency ${String.format(Locale.US, "%.2f", sale.discountAmount)}\n")
        }
        sb.append("*TOTAL AMOUNT:* *$currency ${String.format(Locale.US, "%.2f", sale.totalAmount)}*\n")
        sb.append("Payment Method: ${sale.paymentMethod.replace('_', ' ')}\n")
        sb.append("Amount Paid: $currency ${String.format(Locale.US, "%.2f", sale.amountPaid)}\n")
        if (sale.creditAmount > 0.0) {
            sb.append("*Credit / Balance Due:* *$currency ${String.format(Locale.US, "%.2f", sale.creditAmount)}*\n")
        }
        sb.append("--------------------------------\n")
        if (settings.receiptFooter.isNotBlank()) {
            sb.append("${settings.receiptFooter}\n")
        } else {
            sb.append("Ke a leboga! Thank you for your support.\n")
        }

        return sb.toString()
    }

    fun formatDebtReminderMessage(
        settings: ShopSettingsEntity,
        customer: CustomerEntity
    ): String {
        val currency = settings.currencySymbol
        val amountStr = String.format(Locale.US, "%.2f", customer.totalDebt)

        return """
            Dumelang ${customer.name},

            This is a friendly reminder from *${settings.businessName}* regarding your outstanding store account balance of *$currency $amountStr*.

            Kindly arrange payment at your earliest convenience via Cash, Orange Money, Smega, or MyZaka to ${settings.phone}.

            Ke a leboga! Thank you for your continued support.
        """.trimIndent()
    }

    fun cleanPhoneNumber(phone: String): String {
        var clean = phone.replace("[^0-9+]".toRegex(), "")
        if (clean.startsWith("+267")) {
            return clean.removePrefix("+")
        }
        if (clean.startsWith("267")) {
            return clean
        }
        // Botswana mobile numbers start with 71, 72, 73, 74, 75, 76, 77
        if (clean.length == 8 && clean.startsWith("7")) {
            return "267$clean"
        }
        return clean.removePrefix("+")
    }

    /**
     * Opens WhatsApp directly if installed, or falls back to system share sheet.
     * Note: Distinguishes opening share intent from actual message delivery.
     */
    fun shareViaWhatsApp(context: Context, rawPhone: String?, messageText: String) {
        val cleanPhone = if (!rawPhone.isNullOrBlank()) cleanPhoneNumber(rawPhone) else ""
        try {
            if (cleanPhone.isNotBlank()) {
                val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=${URLEncoder.encode(messageText, "UTF-8")}"
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse(url)
                    setPackage("com.whatsapp")
                }
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                    return
                }
                // Try WhatsApp Business package
                intent.setPackage("com.whatsapp.w4b")
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                    return
                }
                // Browser / general handler
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(webIntent)
            } else {
                // System share sheet
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, messageText)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Receipt via WhatsApp or App"))
            }
        } catch (e: Exception) {
            // General share fallback
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, messageText)
            }
            try {
                context.startActivity(Intent.createChooser(shareIntent, "Share Receipt"))
            } catch (ex: Exception) {
                Toast.makeText(context, "Could not open share screen: ${ex.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
