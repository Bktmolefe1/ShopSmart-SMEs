package com.example.ui.screens.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.domain.model.CartItem
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwGreenSuccess
import com.example.ui.theme.BwRedDanger
import com.example.util.CurrencyFormatter

val POS_CATEGORIES = listOf("All", "Groceries", "Beverages", "Bakery", "Dairy & Eggs", "Cleaning", "Confectionery", "Airtime")

val PAYMENT_METHODS = listOf(
    "CASH" to "Cash",
    "ORANGE_MONEY" to "Orange Money",
    "SMEGA" to "Smega (BTC)",
    "MYZAKA" to "MyZaka",
    "CARD" to "Card / eWallet",
    "CREDIT" to "Credit Sale",
    "SPLIT" to "Split Payment"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesPosScreen(
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    cartItems: List<CartItem>,
    discountAmount: Double,
    selectedCustomer: CustomerEntity?,
    settings: ShopSettingsEntity,
    onAddToCart: (ProductEntity) -> Unit,
    onUpdateCartQuantity: (Long, Double) -> Unit,
    onRemoveFromCart: (Long) -> Unit,
    onSetDiscount: (Double) -> Unit,
    onSelectCustomer: (CustomerEntity?) -> Unit,
    onCheckout: (String, Double, Double, String, String) -> Unit,
    onClearCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showCartSheet by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }

    // Filter products
    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { p ->
            val matchesCategory = (selectedCategory == "All") || p.category.equals(selectedCategory, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.skuOrBarcode.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    val cartTotalCount = cartItems.sumOf { it.quantity }
    val cartGrossSubtotal = cartItems.sumOf { it.finalSubtotal }
    val cartFinalTotal = (cartGrossSubtotal - discountAmount).coerceAtLeast(0.0)

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Search Bar & Barcode/SKU input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pos_search_input"),
                placeholder = { Text("Search product name, barcode or SKU...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = BwBluePrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    } else {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Category Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                POS_CATEGORIES.forEach { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Product List
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isBlank()) "No products in this category" else "No matching products found",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        val itemInCart = cartItems.find { it.product.id == product.id }
                        ProductPosCard(
                            product = product,
                            currencySymbol = settings.currencySymbol,
                            quantityInCart = itemInCart?.quantity ?: 0.0,
                            onAddToCart = { onAddToCart(product) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp)) // Padding for bottom cart bar
                    }
                }
            }
        }

        // Floating Bottom Cart Action Bar
        if (cartItems.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                color = BwBluePrimary,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCartSheet = true }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("floating_cart_bar"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BadgedBox(badge = {
                            Badge(containerColor = Color(0xFFD97706)) {
                                Text(
                                    text = if (cartTotalCount % 1.0 == 0.0) cartTotalCount.toInt().toString() else String.format(java.util.Locale.US, "%.1f", cartTotalCount),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "View Cart",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (selectedCustomer != null) {
                                Text(
                                    text = "Customer: ${selectedCustomer.name}",
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = CurrencyFormatter.format(cartFinalTotal, settings.currencySymbol),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { showCheckoutDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BwBluePrimary),
                            modifier = Modifier.testTag("cart_bar_checkout_button")
                        ) {
                            Text("Checkout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet for Cart Detail
    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            CartSheetContent(
                cartItems = cartItems,
                discountAmount = discountAmount,
                cartFinalTotal = cartFinalTotal,
                currencySymbol = settings.currencySymbol,
                customers = customers,
                selectedCustomer = selectedCustomer,
                onUpdateQuantity = onUpdateCartQuantity,
                onRemoveItem = onRemoveFromCart,
                onSetDiscount = onSetDiscount,
                onSelectCustomer = onSelectCustomer,
                onClearCart = {
                    onClearCart()
                    showCartSheet = false
                },
                onProceedToCheckout = {
                    showCartSheet = false
                    showCheckoutDialog = true
                }
            )
        }
    }

    // Checkout Dialog
    if (showCheckoutDialog && cartItems.isNotEmpty()) {
        CheckoutDialog(
            cartItems = cartItems,
            totalAmount = cartFinalTotal,
            currencySymbol = settings.currencySymbol,
            customers = customers,
            selectedCustomer = selectedCustomer,
            onSelectCustomer = onSelectCustomer,
            onDismiss = { showCheckoutDialog = false },
            onConfirmSale = { method, paid, credit, splitNotes, notes ->
                onCheckout(method, paid, credit, splitNotes, notes)
                showCheckoutDialog = false
            }
        )
    }
}

@Composable
private fun ProductPosCard(
    product: ProductEntity,
    currencySymbol: String,
    quantityInCart: Double,
    onAddToCart: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onAddToCart)
            .testTag("pos_product_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = product.category,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // Stock badge
                    val isOutOfStock = product.quantity <= 0.0
                    val isLowStock = product.quantity <= product.minStockLevel && !isOutOfStock
                    val (badgeText, badgeBg, badgeTextColor) = when {
                        isOutOfStock -> Triple("Out of stock", Color(0xFFFEE2E2), Color(0xFFDC2626))
                        isLowStock -> Triple("${product.quantity.toInt()} left (Low)", Color(0xFFFEF3C7), Color(0xFFD97706))
                        else -> Triple("${product.quantity.toInt()} in stock", Color(0xFFD1FAE5), Color(0xFF059669))
                    }
                    Surface(color = badgeBg, shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = badgeText,
                            color = badgeTextColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = CurrencyFormatter.format(product.sellingPrice, currencySymbol),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BwBluePrimary
                    )
                    if (quantityInCart > 0.0) {
                        Text(
                            text = "${if (quantityInCart % 1.0 == 0.0) quantityInCart.toInt().toString() else quantityInCart.toString()} in cart",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = BwGreenSuccess
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onAddToCart,
                    modifier = Modifier
                        .size(36.dp)
                        .background(BwBluePrimary, CircleShape)
                        .testTag("add_to_cart_btn_${product.id}")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add to Cart", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun CartSheetContent(
    cartItems: List<CartItem>,
    discountAmount: Double,
    cartFinalTotal: Double,
    currencySymbol: String,
    customers: List<CustomerEntity>,
    selectedCustomer: CustomerEntity?,
    onUpdateQuantity: (Long, Double) -> Unit,
    onRemoveItem: (Long) -> Unit,
    onSetDiscount: (Double) -> Unit,
    onSelectCustomer: (CustomerEntity?) -> Unit,
    onClearCart: () -> Unit,
    onProceedToCheckout: () -> Unit
) {
    var discountInput by remember { mutableStateOf(if (discountAmount > 0.0) discountAmount.toString() else "") }
    var showCustomerPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Current Cart (${cartItems.size} items)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            TextButton(onClick = onClearCart) {
                Text("Clear Cart", color = BwRedDanger)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Customer selection bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showCustomerPicker = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = BwBluePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    if (selectedCustomer != null) {
                        Column {
                            Text(selectedCustomer.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(selectedCustomer.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        Text("Walk-in Customer (Tap to select for credit/loyalty)", fontSize = 12.sp)
                    }
                }
                if (selectedCustomer != null) {
                    IconButton(onClick = { onSelectCustomer(null) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Remove Customer")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Cart items list
        LazyColumn(
            modifier = Modifier
                .weight(1f, fill = false)
                .height(240.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(cartItems, key = { it.product.id }) { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.product.name, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text(
                            "${CurrencyFormatter.format(item.unitPrice, currencySymbol)} each",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Stepper: - QTY +
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onUpdateQuantity(item.product.id, item.quantity - 1.0) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }
                        Text(
                            text = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString(),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(
                            onClick = { onUpdateQuantity(item.product.id, item.quantity + 1.0) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = CurrencyFormatter.format(item.finalSubtotal, currencySymbol),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        IconButton(
                            onClick = { onRemoveItem(item.product.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Discount input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = discountInput,
                onValueChange = {
                    discountInput = it
                    onSetDiscount(it.toDoubleOrNull() ?: 0.0)
                },
                label = { Text("Discount ($currencySymbol)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("cart_discount_input")
            )
            Column(horizontalAlignment = Alignment.End) {
                Text("Total to Pay", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    CurrencyFormatter.format(cartFinalTotal, currencySymbol),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = BwBluePrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = onProceedToCheckout,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("cart_proceed_to_checkout_button"),
            colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
        ) {
            Text("Proceed to Payment", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }

    if (showCustomerPicker) {
        CustomerPickerDialog(
            customers = customers,
            onSelect = {
                onSelectCustomer(it)
                showCustomerPicker = false
            },
            onDismiss = { showCustomerPicker = false }
        )
    }
}

@Composable
private fun CheckoutDialog(
    cartItems: List<CartItem>,
    totalAmount: Double,
    currencySymbol: String,
    customers: List<CustomerEntity>,
    selectedCustomer: CustomerEntity?,
    onSelectCustomer: (CustomerEntity?) -> Unit,
    onDismiss: () -> Unit,
    onConfirmSale: (method: String, paid: Double, credit: Double, splitNotes: String, notes: String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("CASH") }
    var cashTenderedText by remember { mutableStateOf(String.format(java.util.Locale.US, "%.2f", totalAmount)) }
    var splitCashText by remember { mutableStateOf(String.format(java.util.Locale.US, "%.2f", totalAmount / 2.0)) }
    var splitOtherMethod by remember { mutableStateOf("ORANGE_MONEY") }
    var saleNotes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }
    var showCustomerPicker by remember { mutableStateOf(false) }

    val tendered = cashTenderedText.toDoubleOrNull() ?: 0.0
    val changeDue = (tendered - totalAmount).coerceAtLeast(0.0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Checkout & Payment", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Total display banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("TOTAL AMOUNT DUE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            text = CurrencyFormatter.format(totalAmount, currencySymbol),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = BwBluePrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Payment Method", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                // Payment method chips
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PAYMENT_METHODS.chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (code, label) ->
                                FilterChip(
                                    selected = selectedMethod == code,
                                    onClick = {
                                        selectedMethod = code
                                        validationError = null
                                    },
                                    label = { Text(label, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Specific payment workflows
                when (selectedMethod) {
                    "CASH" -> {
                        Text("Cash Tendered", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = cashTenderedText,
                            onValueChange = { cashTenderedText = it },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("cash_tendered_input"),
                            singleLine = true
                        )
                        // Quick cash note buttons (P20, P50, P100, P200)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(20.0, 50.0, 100.0, 200.0).forEach { note ->
                                OutlinedButton(
                                    onClick = { cashTenderedText = String.format(java.util.Locale.US, "%.2f", note) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("P${note.toInt()}", fontSize = 11.sp)
                                }
                            }
                        }

                        if (tendered >= totalAmount) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFD1FAE5))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Change Due to Customer:", fontWeight = FontWeight.Bold, color = Color(0xFF065F46))
                                    Text(CurrencyFormatter.format(changeDue, currencySymbol), fontWeight = FontWeight.Bold, color = Color(0xFF065F46))
                                }
                            }
                        }
                    }

                    "CREDIT" -> {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Customer Credit Sale", fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                Text(
                                    "This full amount (${CurrencyFormatter.format(totalAmount, currencySymbol)}) will be added to the customer's outstanding debt ledger.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF7F1D1D)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                if (selectedCustomer != null) {
                                    Text("Selected: ${selectedCustomer.name} (${selectedCustomer.phone})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                } else {
                                    Button(
                                        onClick = { showCustomerPicker = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = BwRedDanger)
                                    ) {
                                        Text("Select Customer for Credit")
                                    }
                                }
                            }
                        }
                    }

                    "SPLIT" -> {
                        Text("Split Payment Details", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = splitCashText,
                            onValueChange = { splitCashText = it },
                            label = { Text("Cash Portion ($currencySymbol)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        val cashPortion = splitCashText.toDoubleOrNull() ?: 0.0
                        val remainingPortion = (totalAmount - cashPortion).coerceAtLeast(0.0)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Remaining Balance ($currencySymbol${String.format(java.util.Locale.US, "%.2f", remainingPortion)}) via:",
                            fontSize = 12.sp
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("ORANGE_MONEY", "SMEGA", "CREDIT").forEach { meth ->
                                FilterChip(
                                    selected = splitOtherMethod == meth,
                                    onClick = { splitOtherMethod = meth },
                                    label = { Text(meth.replace('_', ' '), fontSize = 11.sp) }
                                )
                            }
                        }
                        if (splitOtherMethod == "CREDIT" && selectedCustomer == null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(onClick = { showCustomerPicker = true }) {
                                Text("Select Customer for Credit Portion")
                            }
                        }
                    }

                    else -> {
                        // Mobile money / card
                        Text(
                            text = "Customer will pay via ${selectedMethod.replace('_', ' ')}.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = saleNotes,
                    onValueChange = { saleNotes = it },
                    label = { Text("Notes (Optional)") },
                    placeholder = { Text("e.g. Reference code, receipt note") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (validationError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(validationError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        when (selectedMethod) {
                            "CASH" -> {
                                if (tendered < totalAmount) {
                                    validationError = "Cash tendered is less than total amount!"
                                    return@Button
                                }
                                onConfirmSale("CASH", totalAmount, 0.0, "", saleNotes)
                            }
                            "CREDIT" -> {
                                if (selectedCustomer == null) {
                                    validationError = "You must select a customer for credit sales!"
                                    return@Button
                                }
                                onConfirmSale("CREDIT", 0.0, totalAmount, "Full credit sale", saleNotes)
                            }
                            "SPLIT" -> {
                                val cashPortion = splitCashText.toDoubleOrNull() ?: 0.0
                                val otherPortion = (totalAmount - cashPortion).coerceAtLeast(0.0)
                                if (splitOtherMethod == "CREDIT" && selectedCustomer == null) {
                                    validationError = "Customer must be selected for credit portion!"
                                    return@Button
                                }
                                val splitDetail = "Cash: P${String.format(java.util.Locale.US, "%.2f", cashPortion)}, $splitOtherMethod: P${String.format(java.util.Locale.US, "%.2f", otherPortion)}"
                                val creditAmt = if (splitOtherMethod == "CREDIT") otherPortion else 0.0
                                val paidAmt = totalAmount - creditAmt
                                onConfirmSale("SPLIT", paidAmt, creditAmt, splitDetail, saleNotes)
                            }
                            else -> {
                                onConfirmSale(selectedMethod, totalAmount, 0.0, "", saleNotes)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_checkout_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
                ) {
                    Text("Complete Sale", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }

    if (showCustomerPicker) {
        CustomerPickerDialog(
            customers = customers,
            onSelect = {
                onSelectCustomer(it)
                showCustomerPicker = false
            },
            onDismiss = { showCustomerPicker = false }
        )
    }
}

@Composable
private fun CustomerPickerDialog(
    customers: List<CustomerEntity>,
    onSelect: (CustomerEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(customers, query) {
        if (query.isBlank()) customers else customers.filter {
            it.name.contains(query, ignoreCase = true) || it.phone.contains(query)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Customer") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search customer...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.height(200.dp)) {
                    items(filtered) { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(c) }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(c.name, fontWeight = FontWeight.Bold)
                                Text(c.phone, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (c.totalDebt > 0.0) {
                                Text("Owes P${String.format(java.util.Locale.US, "%.2f", c.totalDebt)}", color = Color(0xFFDC2626), fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
