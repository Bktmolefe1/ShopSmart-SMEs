package com.example.ui.screens.customers

import android.content.Context
import java.util.Locale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwGreenSuccess
import com.example.ui.theme.BwRedDanger
import com.example.util.CurrencyFormatter
import com.example.util.WhatsAppHelper

@Composable
fun CustomersScreen(
    customers: List<CustomerEntity>,
    settings: ShopSettingsEntity,
    onSaveCustomer: (CustomerEntity) -> Unit,
    onDeleteCustomer: (CustomerEntity) -> Unit,
    onRecordRepayment: (customerId: Long, amount: Double, paymentMethod: String, notes: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var filterWithDebtOnly by remember { mutableStateOf(false) }

    // Dialog states
    var isAddingCustomer by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerToRepay by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerToDelete by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerDetailStatement by remember { mutableStateOf<CustomerEntity?>(null) }

    val totalDebt = remember(customers) { customers.sumOf { it.totalDebt } }
    val owingCustomerCount = remember(customers) { customers.count { it.totalDebt > 0.0 } }

    val filteredCustomers = remember(customers, searchQuery, filterWithDebtOnly) {
        customers.filter { c ->
            val matchesQuery = searchQuery.isBlank() ||
                    c.name.contains(searchQuery, ignoreCase = true) ||
                    c.phone.contains(searchQuery)
            val matchesDebt = !filterWithDebtOnly || c.totalDebt > 0.0
            matchesQuery && matchesDebt
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Debt Ledger Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (totalDebt > 0) Color(0xFFFEE2E2) else Color(0xFFD1FAE5)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Total Outstanding Customer Debt",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (totalDebt > 0) Color(0xFF991B1B) else Color(0xFF065F46)
                        )
                        Text(
                            CurrencyFormatter.format(totalDebt, settings.currencySymbol),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = if (totalDebt > 0) Color(0xFFDC2626) else Color(0xFF059669)
                        )
                    }
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "$owingCustomerCount Customers Owe",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (totalDebt > 0) Color(0xFFDC2626) else Color(0xFF059669),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_search_input"),
                placeholder = { Text("Search customer name or phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BwBluePrimary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Filter chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !filterWithDebtOnly,
                    onClick = { filterWithDebtOnly = false },
                    label = { Text("All Customers (${customers.size})") }
                )
                FilterChip(
                    selected = filterWithDebtOnly,
                    onClick = { filterWithDebtOnly = true },
                    label = { Text("Owing Debts Only ($owingCustomerCount)") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Customer List
            if (filteredCustomers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No customers found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        CustomerCard(
                            customer = customer,
                            currencySymbol = settings.currencySymbol,
                            onRepayClick = { customerToRepay = customer },
                            onWhatsAppReminder = {
                                val message = WhatsAppHelper.formatDebtReminderMessage(settings, customer)
                                WhatsAppHelper.shareViaWhatsApp(context, customer.phone, message)
                            },
                            onDetailClick = { customerDetailStatement = customer },
                            onEditClick = { customerToEdit = customer },
                            onDeleteClick = { customerToDelete = customer }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }

        // FAB to Add Customer
        FloatingActionButton(
            onClick = { isAddingCustomer = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_customer_fab"),
            containerColor = BwBluePrimary,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Customer")
        }
    }

    // Add / Edit Customer Dialog
    if (isAddingCustomer || customerToEdit != null) {
        CustomerEditDialog(
            customer = customerToEdit,
            onDismiss = {
                isAddingCustomer = false
                customerToEdit = null
            },
            onSave = {
                onSaveCustomer(it)
                isAddingCustomer = false
                customerToEdit = null
            }
        )
    }

    // Repay Debt Dialog
    if (customerToRepay != null) {
        RepayDebtDialog(
            customer = customerToRepay!!,
            currencySymbol = settings.currencySymbol,
            onDismiss = { customerToRepay = null },
            onConfirm = { amount, method, notes ->
                onRecordRepayment(customerToRepay!!.id, amount, method, notes)
                customerToRepay = null
            }
        )
    }

    // Customer Statement Dialog
    if (customerDetailStatement != null) {
        CustomerStatementDialog(
            customer = customerDetailStatement!!,
            currencySymbol = settings.currencySymbol,
            onDismiss = { customerDetailStatement = null }
        )
    }

    // Delete Confirmation
    if (customerToDelete != null) {
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("Delete Customer?") },
            text = { Text("Are you sure you want to delete '${customerToDelete!!.name}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCustomer(customerToDelete!!)
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BwRedDanger)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CustomerCard(
    customer: CustomerEntity,
    currencySymbol: String,
    onRepayClick: () -> Unit,
    onWhatsAppReminder: () -> Unit,
    onDetailClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onDetailClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (customer.phone.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(customer.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (customer.notes.isNotBlank()) {
                        Text(
                            text = customer.notes,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }

                // Balance Badge
                if (customer.totalDebt > 0.0) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Owes Store", fontSize = 10.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.SemiBold)
                        Text(
                            CurrencyFormatter.format(customer.totalDebt, currencySymbol),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFFDC2626)
                        )
                    }
                } else {
                    Surface(color = Color(0xFFD1FAE5), shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = "SETTLED / P0.00",
                            color = Color(0xFF047857),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(4.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Total Paid to Date: ${CurrencyFormatter.format(customer.totalPaid, currencySymbol)}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (customer.totalDebt > 0.0) {
                        Button(
                            onClick = onRepayClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BwGreenSuccess),
                            modifier = Modifier.height(34.dp).testTag("repay_debt_btn_${customer.id}")
                        ) {
                            Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Repay", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(onClick = onWhatsAppReminder, modifier = Modifier.size(34.dp).testTag("whatsapp_reminder_btn_${customer.id}")) {
                            Icon(Icons.Default.Share, contentDescription = "Send WhatsApp Reminder", tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(onClick = onEditClick, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Customer", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Customer", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerEditDialog(
    customer: CustomerEntity?,
    onDismiss: () -> Unit,
    onSave: (CustomerEntity) -> Unit
) {
    var name by remember { mutableStateOf(customer?.name ?: "") }
    var phone by remember { mutableStateOf(customer?.phone ?: "") }
    var notes by remember { mutableStateOf(customer?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (customer == null) "Add Customer" else "Edit Customer") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("Customer Full Name *") },
                    placeholder = { Text("e.g. Lesego Tau") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("customer_name_input"),
                    isError = error != null
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone / WhatsApp") },
                    placeholder = { Text("+267 71 234 567") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("customer_phone_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Ward / Settlement") },
                    placeholder = { Text("e.g. Near kgotla, pays end of month") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        error = "Customer name is required"
                        return@Button
                    }
                    val toSave = (customer ?: CustomerEntity(name = "")).copy(
                        name = name.trim(),
                        phone = phone.trim(),
                        notes = notes.trim()
                    )
                    onSave(toSave)
                },
                colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary),
                modifier = Modifier.testTag("save_customer_confirm_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun RepayDebtDialog(
    customer: CustomerEntity,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (amount: Double, method: String, notes: String) -> Unit
) {
    var amountText by remember { mutableStateOf(String.format(Locale.US, "%.2f", customer.totalDebt)) }
    var selectedMethod by remember { mutableStateOf("CASH") }
    var notes by remember { mutableStateOf("Account repayment") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Debt Repayment") },
        text = {
            Column {
                Text(
                    text = "Customer: ${customer.name}",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Current Balance Owed: ${CurrencyFormatter.format(customer.totalDebt, currencySymbol)}",
                    color = Color(0xFFDC2626),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("Repayment Amount ($currencySymbol) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("repayment_amount_input")
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("Payment Method", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("CASH", "ORANGE_MONEY", "SMEGA", "CARD").forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = { selectedMethod = method },
                            label = { Text(method.replace('_', ' '), fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Receipt Reference") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0.0) {
                        error = "Enter a valid payment amount"
                        return@Button
                    }
                    if (amount > customer.totalDebt) {
                        error = "Repayment cannot exceed remaining debt (${CurrencyFormatter.format(customer.totalDebt, currencySymbol)})"
                        return@Button
                    }
                    onConfirm(amount, selectedMethod, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = BwGreenSuccess),
                modifier = Modifier.testTag("confirm_repay_button")
            ) {
                Text("Confirm Repayment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun CustomerStatementDialog(
    customer: CustomerEntity,
    currencySymbol: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Customer Statement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Phone: ${if (customer.phone.isBlank()) "None" else customer.phone}", fontSize = 12.sp)
                        if (customer.notes.isNotBlank()) {
                            Text("Notes: ${customer.notes}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Current Outstanding Debt:", fontWeight = FontWeight.Bold)
                            Text(
                                CurrencyFormatter.format(customer.totalDebt, currencySymbol),
                                fontWeight = FontWeight.Bold,
                                color = if (customer.totalDebt > 0) Color(0xFFDC2626) else Color(0xFF059669)
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Paid Historically:")
                            Text(CurrencyFormatter.format(customer.totalPaid, currencySymbol), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
                ) {
                    Text("Close")
                }
            }
        }
    }
}
