package com.example.ui.screens.expenses

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.ExpenseEntity
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwRedDanger
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val EXPENSE_CATEGORIES = listOf(
    "Rent",
    "Electricity",
    "Transport",
    "Wages",
    "Internet & Airtime",
    "Repairs",
    "Packaging",
    "Stock Transport",
    "Miscellaneous"
)

@Composable
fun ExpensesDialog(
    expenses: List<ExpenseEntity>,
    currencySymbol: String,
    onSaveExpense: (ExpenseEntity) -> Unit,
    onReverseExpense: (Long, String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Record, 1: History

    // Form fields
    var selectedCategory by remember { mutableStateOf("Rent") }
    var amountText by remember { mutableStateOf("") }
    var descriptionText by remember { mutableStateOf("") }
    var supplierText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("CASH") }
    var formError by remember { mutableStateOf<String?>(null) }

    // Reversal dialog state
    var expenseToReverse by remember { mutableStateOf<ExpenseEntity?>(null) }
    var reversalReason by remember { mutableStateOf("Incorrect entry") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .height(640.dp)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MoneyOff,
                            contentDescription = null,
                            tint = BwRedDanger,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Shop Expenses",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_expenses_dialog")) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Record Expense", fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Expense History (${expenses.size})", fontWeight = FontWeight.SemiBold) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedTab == 0) {
                    // Record Expense Form
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text("Expense Category", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            // Chips
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                val chunked = EXPENSE_CATEGORIES.chunked(3)
                                chunked.forEach { rowCategories ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        rowCategories.forEach { cat ->
                                            FilterChip(
                                                selected = selectedCategory == cat,
                                                onClick = { selectedCategory = cat },
                                                label = { Text(cat, fontSize = 11.sp) }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = amountText,
                                onValueChange = { amountText = it; formError = null },
                                label = { Text("Amount ($currencySymbol)") },
                                placeholder = { Text("e.g. 150.00") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("expense_amount_input"),
                                isError = formError != null
                            )
                            if (formError != null) {
                                Text(formError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = descriptionText,
                                onValueChange = { descriptionText = it },
                                label = { Text("Description / Reason") },
                                placeholder = { Text("e.g. BPC Prepaid electricity token") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("expense_description_input")
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = supplierText,
                                onValueChange = { supplierText = it },
                                label = { Text("Supplier / Recipient (Optional)") },
                                placeholder = { Text("e.g. Landlord Rre Phiri / BPC") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        item {
                            Text("Payment Method", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("CASH", "ORANGE_MONEY", "SMEGA", "CARD").forEach { method ->
                                    FilterChip(
                                        selected = paymentMethod == method,
                                        onClick = { paymentMethod = method },
                                        label = { Text(method.replace('_', ' '), fontSize = 12.sp) }
                                    )
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    val amount = amountText.toDoubleOrNull()
                                    if (amount == null || amount <= 0.0) {
                                        formError = "Please enter a valid amount"
                                        return@Button
                                    }
                                    if (descriptionText.isBlank()) {
                                        descriptionText = selectedCategory
                                    }
                                    val exp = ExpenseEntity(
                                        category = selectedCategory,
                                        amount = amount,
                                        paymentMethod = paymentMethod,
                                        description = descriptionText.trim(),
                                        supplierOrRecipient = supplierText.trim(),
                                        date = System.currentTimeMillis()
                                    )
                                    onSaveExpense(exp)
                                    amountText = ""
                                    descriptionText = ""
                                    supplierText = ""
                                    selectedTab = 1
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("save_expense_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Record Expense", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // History list
                    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.US) }
                    if (expenses.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No expenses recorded yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(expenses, key = { it.id }) { item ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (item.isReversed) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = item.category,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                                if (item.isReversed) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = Color(0xFFFEE2E2),
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = "REVERSED",
                                                            color = Color(0xFFDC2626),
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                            Text(
                                                text = item.description,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "${dateFormat.format(Date(item.date))} • ${item.paymentMethod.replace('_', ' ')}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = CurrencyFormatter.format(item.amount, currencySymbol),
                                                fontWeight = FontWeight.Bold,
                                                color = if (item.isReversed) Color.Gray else BwRedDanger,
                                                fontSize = 14.sp
                                            )
                                            if (!item.isReversed) {
                                                IconButton(
                                                    onClick = { expenseToReverse = item },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Undo,
                                                        contentDescription = "Reverse Expense",
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Reversal confirmation dialog
    if (expenseToReverse != null) {
        AlertDialog(
            onDismissRequest = { expenseToReverse = null },
            title = { Text("Reverse Expense?") },
            text = {
                Column {
                    Text("This preserves an audit trail and adjusts net profit calculations.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reversalReason,
                        onValueChange = { reversalReason = it },
                        label = { Text("Reason for Reversal") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReverseExpense(expenseToReverse!!.id, reversalReason)
                        expenseToReverse = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BwRedDanger)
                ) {
                    Text("Confirm Reversal")
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToReverse = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
