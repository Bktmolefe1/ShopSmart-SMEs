package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.domain.model.DateFilterPeriod
import com.example.domain.model.FinancialReportSummary
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwGold
import com.example.ui.theme.BwGreenSuccess
import com.example.ui.theme.BwRedDanger
import com.example.util.CurrencyFormatter
import com.example.util.WhatsAppHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    report: FinancialReportSummary,
    selectedPeriod: DateFilterPeriod,
    settings: ShopSettingsEntity,
    lowStockProducts: List<ProductEntity>,
    recentSales: List<SaleEntity>,
    onSelectPeriod: (DateFilterPeriod) -> Unit,
    onNavigateToSales: () -> Unit,
    onNavigateToStock: () -> Unit,
    onNavigateToCustomers: () -> Unit,
    onOpenExpensesDialog: () -> Unit,
    onCancelSale: (Long, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.US) }
    var saleToCancel by remember { mutableStateOf<SaleEntity?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Period Filter Chips
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DateFilterPeriod.values().forEach { period ->
                    FilterChip(
                        selected = selectedPeriod == period,
                        onClick = { onSelectPeriod(period) },
                        label = { Text(period.label, fontSize = 12.sp) },
                        modifier = Modifier.testTag("filter_${period.name.lowercase()}")
                    )
                }
            }
        }

        // Quick Action Buttons
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Quick Actions",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.PointOfSale,
                            label = "New Sale",
                            backgroundColor = BwBluePrimary,
                            testTag = "quick_new_sale_button",
                            onClick = onNavigateToSales
                        )
                        QuickActionButton(
                            icon = Icons.Default.Inventory,
                            label = "Add Stock",
                            backgroundColor = BwGold,
                            testTag = "quick_add_stock_button",
                            onClick = onNavigateToStock
                        )
                        QuickActionButton(
                            icon = Icons.Default.MoneyOff,
                            label = "Expenses",
                            backgroundColor = BwRedDanger,
                            testTag = "quick_expense_button",
                            onClick = onOpenExpensesDialog
                        )
                        QuickActionButton(
                            icon = Icons.Default.People,
                            label = "Customers",
                            backgroundColor = Color(0xFF0284C7),
                            testTag = "quick_customers_button",
                            onClick = onNavigateToCustomers
                        )
                    }
                }
            }
        }

        // Low stock warning banner if any
        if (lowStockProducts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToStock() },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = BwGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${lowStockProducts.size} Products Low in Stock!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF78350F)
                                )
                                Text(
                                    text = lowStockProducts.take(3).joinToString(", ") { "${it.name} (${it.quantity.toInt()} left)" },
                                    fontSize = 11.sp,
                                    color = Color(0xFF92400E),
                                    maxLines = 1
                                )
                            }
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = "View Stock", tint = BwGold)
                    }
                }
            }
        }

        // Primary KPIs: Sales Revenue & Net Operating Profit
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    title = "${selectedPeriod.label}'s Sales",
                    value = CurrencyFormatter.format(report.salesRevenue, settings.currencySymbol),
                    subtitle = "${report.salesCount} transactions",
                    icon = Icons.Default.AttachMoney,
                    iconColor = BwBluePrimary,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_sales_revenue"
                )
                MetricCard(
                    title = "Net Operating Profit",
                    value = CurrencyFormatter.format(report.netOperatingProfit, settings.currencySymbol),
                    subtitle = "Gross: ${CurrencyFormatter.format(report.grossProfit, settings.currencySymbol)}",
                    icon = Icons.Default.TrendingUp,
                    iconColor = if (report.netOperatingProfit >= 0.0) BwGreenSuccess else BwRedDanger,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_net_profit"
                )
            }
        }

        // Second Row: Cash In vs Operating Expenses
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    title = "Cash Collected",
                    value = CurrencyFormatter.format(report.cashReceived, settings.currencySymbol),
                    subtitle = "POS Cash + Repayments",
                    icon = Icons.Default.AccountBalanceWallet,
                    iconColor = BwGreenSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Expenses Paid",
                    value = CurrencyFormatter.format(report.operatingExpenses, settings.currencySymbol),
                    subtitle = "Operational costs",
                    icon = Icons.Default.MoneyOff,
                    iconColor = BwRedDanger,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Third Row: Credit Sales & Outstanding Customer Debt
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    title = "Customer Debts",
                    value = CurrencyFormatter.format(report.totalOutstandingDebt, settings.currencySymbol),
                    subtitle = "Tap to open ledger",
                    icon = Icons.Default.CreditCard,
                    iconColor = Color(0xFFDC2626),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToCustomers() }
                )
                MetricCard(
                    title = "Stock Value (Cost)",
                    value = CurrencyFormatter.format(report.totalStockValuationCost, settings.currencySymbol),
                    subtitle = "Total inventory at cost",
                    icon = Icons.Default.Inventory,
                    iconColor = Color(0xFF0284C7),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToStock() }
                )
            }
        }

        // Recent Sales Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Transactions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onNavigateToSales) {
                    Text("POS Checkout")
                }
            }
        }

        if (recentSales.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No sales recorded yet. Tap 'New Sale' to begin!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            items(recentSales.take(15), key = { it.id }) { sale ->
                RecentSaleCard(
                    sale = sale,
                    currencySymbol = settings.currencySymbol,
                    dateFormat = dateFormat,
                    onShareReceipt = {
                        val message = "Receipt ${sale.receiptNumber} from ${settings.businessName}\nDate: ${dateFormat.format(Date(sale.timestamp))}\nTotal: ${CurrencyFormatter.format(sale.totalAmount, settings.currencySymbol)}\nPaid: ${CurrencyFormatter.format(sale.amountPaid, settings.currencySymbol)}\nMethod: ${sale.paymentMethod}"
                        WhatsAppHelper.shareViaWhatsApp(context, sale.customerPhone, message)
                    },
                    onCancelClick = {
                        saleToCancel = sale
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Cancel Sale Dialog
    if (saleToCancel != null) {
        var cancelReason by remember { mutableStateOf("Customer returned items") }
        AlertDialog(
            onDismissRequest = { saleToCancel = null },
            title = { Text("Cancel / Refund Sale?") },
            text = {
                Column {
                    Text("Cancelling Receipt ${saleToCancel!!.receiptNumber} will restore all inventory items back to stock and reverse customer credit.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = {}) {
                        Text("Reason: $cancelReason")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelSale(saleToCancel!!.id, cancelReason)
                        saleToCancel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BwRedDanger)
                ) {
                    Text("Confirm Cancellation")
                }
            },
            dismissButton = {
                TextButton(onClick = { saleToCancel = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    label: String,
    backgroundColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
            .padding(4.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = backgroundColor,
            modifier = Modifier.size(46.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        modifier = modifier.testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RecentSaleCard(
    sale: SaleEntity,
    currencySymbol: String,
    dateFormat: SimpleDateFormat,
    onShareReceipt: () -> Unit,
    onCancelClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (sale.status == "CANCELLED") MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = sale.receiptNumber,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                    if (sale.status == "CANCELLED") {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(color = Color(0xFFFEE2E2), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "CANCELLED",
                                color = Color(0xFFDC2626),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = "${dateFormat.format(Date(sale.timestamp))} • ${sale.paymentMethod.replace('_', ' ')}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!sale.customerName.isNullOrBlank()) {
                    Text(
                        text = "Customer: ${sale.customerName}",
                        fontSize = 11.sp,
                        color = BwBluePrimary
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyFormatter.format(sale.totalAmount, currencySymbol),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                if (sale.creditAmount > 0.0) {
                    Text(
                        text = "Credit: ${CurrencyFormatter.format(sale.creditAmount, currencySymbol)}",
                        fontSize = 10.sp,
                        color = Color(0xFFDC2626),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (sale.status != "CANCELLED") {
                    Row {
                        IconButton(onClick = onShareReceipt, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Share, contentDescription = "Share Receipt", tint = BwBluePrimary, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onCancelClick, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Receipt, contentDescription = "Cancel Sale", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
