package com.example.ui.screens.reports

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.domain.model.DateFilterPeriod
import com.example.domain.model.FinancialReportSummary
import com.example.domain.model.TopProductItem
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwGold
import com.example.ui.theme.BwGreenSuccess
import com.example.ui.theme.BwRedDanger
import com.example.util.CsvExporter
import com.example.util.CurrencyFormatter

@Composable
fun ReportsScreen(
    report: FinancialReportSummary,
    selectedPeriod: DateFilterPeriod,
    settings: ShopSettingsEntity,
    products: List<ProductEntity>,
    sales: List<SaleEntity>,
    customers: List<CustomerEntity>,
    expenses: List<ExpenseEntity>,
    onSelectPeriod: (DateFilterPeriod) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Period Filter Chips
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DateFilterPeriod.values().forEach { period ->
                    FilterChip(
                        selected = selectedPeriod == period,
                        onClick = { onSelectPeriod(period) },
                        label = { Text(period.label, fontSize = 12.sp) },
                        modifier = Modifier.testTag("report_period_${period.name.lowercase()}")
                    )
                }
            }
        }

        // Educational Accounting Principles Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = BwBluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Standard Accounting & Profit Rules",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "• Gross Profit = Recognized Sales minus Cost of Goods Sold (COGS).\n" +
                                    "• Net Operating Profit = Gross Profit minus Operating Expenses.\n" +
                                    "• Cash Flow is tracked separately from Profit.\n" +
                                    "• Basic business management estimates tool.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Primary Financial Summary: Sales -> COGS -> Gross Profit -> Expenses -> Net Profit
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Profit & Loss Breakdown (${selectedPeriod.label})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BwBluePrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ReportLineRow(
                        label = "Sales Revenue (Total Recognized)",
                        value = CurrencyFormatter.format(report.salesRevenue, settings.currencySymbol),
                        valueColor = MaterialTheme.colorScheme.onSurface,
                        isBold = true
                    )
                    ReportLineRow(
                        label = "Less: Cost of Goods Sold (COGS)",
                        value = "-${CurrencyFormatter.format(report.costOfGoodsSold, settings.currencySymbol)}",
                        valueColor = BwRedDanger
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    val grossMargin = if (report.salesRevenue > 0) (report.grossProfit / report.salesRevenue) * 100 else 0.0
                    ReportLineRow(
                        label = "Gross Profit (Margin: ${String.format(java.util.Locale.US, "%.1f%%", grossMargin)})",
                        value = CurrencyFormatter.format(report.grossProfit, settings.currencySymbol),
                        valueColor = if (report.grossProfit >= 0) BwGreenSuccess else BwRedDanger,
                        isBold = true
                    )

                    ReportLineRow(
                        label = "Less: Operating Expenses",
                        value = "-${CurrencyFormatter.format(report.operatingExpenses, settings.currencySymbol)}",
                        valueColor = BwRedDanger
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ReportLineRow(
                        label = "NET OPERATING PROFIT",
                        value = CurrencyFormatter.format(report.netOperatingProfit, settings.currencySymbol),
                        valueColor = if (report.netOperatingProfit >= 0) BwGreenSuccess else BwRedDanger,
                        isBold = true,
                        fontSize = 17.sp
                    )
                }
            }
        }

        // Cash Flow & Accounts Receivable Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Cash Flow & Balances",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF0284C7)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ReportLineRow(
                        label = "Total Cash Inflow (POS + Repayments)",
                        value = CurrencyFormatter.format(report.cashReceived, settings.currencySymbol),
                        valueColor = BwGreenSuccess
                    )
                    ReportLineRow(
                        label = "Total Cash Outflow (Expenses + Stock)",
                        value = "-${CurrencyFormatter.format(report.operatingExpenses + report.stockPurchasesCost, settings.currencySymbol)}",
                        valueColor = BwRedDanger
                    )
                    ReportLineRow(
                        label = "Net Cash Flow",
                        value = CurrencyFormatter.format(report.netCashFlow, settings.currencySymbol),
                        valueColor = if (report.netCashFlow >= 0) BwGreenSuccess else BwRedDanger,
                        isBold = true
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ReportLineRow(
                        label = "Credit Sales in Period (Unpaid)",
                        value = CurrencyFormatter.format(report.creditSales, settings.currencySymbol),
                        valueColor = BwGold
                    )
                    ReportLineRow(
                        label = "Total Customer Debts Outstanding",
                        value = CurrencyFormatter.format(report.totalOutstandingDebt, settings.currencySymbol),
                        valueColor = Color(0xFFDC2626),
                        isBold = true
                    )
                    ReportLineRow(
                        label = "Total Stock Valuation (At Cost)",
                        value = CurrencyFormatter.format(report.totalStockValuationCost, settings.currencySymbol),
                        valueColor = BwBluePrimary,
                        isBold = true
                    )
                }
            }
        }

        // Top Selling Products Leaderboard
        item {
            Text(
                text = "Top Selling Products (${selectedPeriod.label})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (report.topProducts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.padding(20.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No sales data available for this period", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            itemsIndexed(report.topProducts) { index, item ->
                TopProductCard(index = index + 1, item = item, currencySymbol = settings.currencySymbol)
            }
        }

        // CSV Export Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Export Business Data to CSV",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val csv = CsvExporter.exportProductsToCsv(products)
                                shareCsv(context, "shopsmart_products.csv", csv)
                            },
                            modifier = Modifier.weight(1f).testTag("export_products_csv")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Products", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val csv = CsvExporter.exportSalesToCsv(sales)
                                shareCsv(context, "shopsmart_sales.csv", csv)
                            },
                            modifier = Modifier.weight(1f).testTag("export_sales_csv")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sales", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val csv = CsvExporter.exportCustomersToCsv(customers)
                                shareCsv(context, "shopsmart_customers_debts.csv", csv)
                            },
                            modifier = Modifier.weight(1f).testTag("export_debts_csv")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Debts", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val csv = CsvExporter.exportExpensesToCsv(expenses)
                                shareCsv(context, "shopsmart_expenses.csv", csv)
                            },
                            modifier = Modifier.weight(1f).testTag("export_expenses_csv")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Expenses", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ReportLineRow(
    label: String,
    value: String,
    valueColor: Color,
    isBold: Boolean = false,
    fontSize: androidx.compose.ui.unit.TextUnit = 13.sp
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = fontSize,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isBold) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = fontSize,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = valueColor
        )
    }
}

@Composable
private fun TopProductCard(
    index: Int,
    item: TopProductItem,
    currencySymbol: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(
                    shape = CircleShape,
                    color = when (index) {
                        1 -> BwGold
                        2 -> Color(0xFF94A3B8)
                        3 -> Color(0xFFB45309)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = index.toString(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (index <= 3) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(item.productName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(
                        "${if (item.quantitySold % 1.0 == 0.0) item.quantitySold.toInt().toString() else item.quantitySold.toString()} sold",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyFormatter.format(item.revenue, currencySymbol),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = BwBluePrimary
                )
                Text(
                    text = "Profit: ${CurrencyFormatter.format(item.profit, currencySymbol)}",
                    fontSize = 11.sp,
                    color = BwGreenSuccess,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

private fun shareCsv(context: Context, filename: String, csvContent: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, filename)
        putExtra(Intent.EXTRA_TEXT, csvContent)
    }
    context.startActivity(Intent.createChooser(intent, "Share $filename"))
}
