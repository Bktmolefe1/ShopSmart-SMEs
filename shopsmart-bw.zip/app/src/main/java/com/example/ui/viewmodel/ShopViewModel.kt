package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.SampleData
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.DebtPaymentEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.StockMovementEntity
import com.example.data.repository.ShopRepository
import com.example.domain.model.CartItem
import com.example.domain.model.DateFilterPeriod
import com.example.domain.model.FinancialReportSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(
    application: Application,
    private val repository: ShopRepository
) : AndroidViewModel(application) {

    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<ProductEntity>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockCount: StateFlow<Int> = repository.lowStockCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalStockCostValue: StateFlow<Double> = repository.totalStockCostValue
        .combine(MutableStateFlow(0.0)) { cost, _ -> cost ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val allCustomers: StateFlow<List<CustomerEntity>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customersWithDebt: StateFlow<List<CustomerEntity>> = repository.customersWithDebt
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalOutstandingDebt: StateFlow<Double> = repository.totalOutstandingDebt
        .combine(MutableStateFlow(0.0)) { debt, _ -> debt ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val recentSales: StateFlow<List<SaleEntity>> = repository.recentSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSales: StateFlow<List<SaleEntity>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStockMovements: StateFlow<List<StockMovementEntity>> = repository.allStockMovements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shopSettings: StateFlow<ShopSettingsEntity> = repository.shopSettings
        .combine(MutableStateFlow(SampleData.initialSettings)) { current, fallback -> current ?: fallback }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SampleData.initialSettings)

    // POS Cart State
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val selectedCustomer: StateFlow<CustomerEntity?> = _selectedCustomer.asStateFlow()

    private val _cartDiscountAmount = MutableStateFlow(0.0)
    val cartDiscountAmount: StateFlow<Double> = _cartDiscountAmount.asStateFlow()

    // Reports Date Filter State
    private val _selectedPeriod = MutableStateFlow(DateFilterPeriod.TODAY)
    val selectedPeriod: StateFlow<DateFilterPeriod> = _selectedPeriod.asStateFlow()

    private val _financialReport = MutableStateFlow(FinancialReportSummary())
    val financialReport: StateFlow<FinancialReportSummary> = _financialReport.asStateFlow()

    // UI Feedback
    private val _lastCompletedSale = MutableStateFlow<Pair<SaleEntity, List<SaleItemEntity>>?>(null)
    val lastCompletedSale: StateFlow<Pair<SaleEntity, List<SaleItemEntity>>?> = _lastCompletedSale.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        refreshFinancialReport()
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun dismissReceiptDialog() {
        _lastCompletedSale.value = null
    }

    fun setDateFilterPeriod(period: DateFilterPeriod) {
        _selectedPeriod.value = period
        refreshFinancialReport()
    }

    fun refreshFinancialReport() {
        viewModelScope.launch {
            val (start, end) = _selectedPeriod.value.getTimeRange()
            val report = repository.calculateFinancialReport(start, end)
            _financialReport.value = report
        }
    }

    // Cart Operations
    fun addToCart(product: ProductEntity, quantityToAdd: Double = 1.0) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + quantityToAdd)
        } else {
            current.add(CartItem(product = product, quantity = quantityToAdd))
        }
        _cartItems.value = current
    }

    fun updateCartItemQuantity(productId: Long, newQuantity: Double) {
        if (newQuantity <= 0.0) {
            removeFromCart(productId)
            return
        }
        _cartItems.value = _cartItems.value.map {
            if (it.product.id == productId) it.copy(quantity = newQuantity) else it
        }
    }

    fun removeFromCart(productId: Long) {
        _cartItems.value = _cartItems.value.filter { it.product.id != productId }
    }

    fun setCartDiscount(amount: Double) {
        _cartDiscountAmount.value = amount.coerceAtLeast(0.0)
    }

    fun setSelectedCustomer(customer: CustomerEntity?) {
        _selectedCustomer.value = customer
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _cartDiscountAmount.value = 0.0
        _selectedCustomer.value = null
    }

    // Checkout
    fun checkout(
        paymentMethod: String, // CASH, ORANGE_MONEY, SMEGA, MYZAKA, CARD, CREDIT, SPLIT
        amountPaid: Double,
        creditAmount: Double,
        splitDetails: String,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val result = repository.completeSale(
                cartItems = _cartItems.value,
                discountAmount = _cartDiscountAmount.value,
                paymentMethod = paymentMethod,
                amountPaid = amountPaid,
                creditAmount = creditAmount,
                splitDetails = splitDetails,
                customer = _selectedCustomer.value,
                notes = notes
            )
            result.onSuccess { salePair ->
                _lastCompletedSale.value = salePair
                _userMessage.value = "Sale ${salePair.first.receiptNumber} completed successfully!"
                clearCart()
                refreshFinancialReport()
            }.onFailure { err ->
                _userMessage.value = "Checkout failed: ${err.message}"
            }
        }
    }

    // Cancel / Refund Sale
    fun cancelSale(saleId: Long, reason: String) {
        viewModelScope.launch {
            val res = repository.cancelSale(saleId, reason)
            res.onSuccess {
                _userMessage.value = "Sale cancelled and stock restored."
                refreshFinancialReport()
            }.onFailure { err ->
                _userMessage.value = "Error cancelling sale: ${err.message}"
            }
        }
    }

    // Product Management
    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
            _userMessage.value = "Product '${product.name}' saved."
            refreshFinancialReport()
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            _userMessage.value = "Product '${product.name}' deleted."
            refreshFinancialReport()
        }
    }

    fun restockProduct(productId: Long, addedQty: Double, newCostPrice: Double?, notes: String) {
        viewModelScope.launch {
            repository.restockProduct(productId, addedQty, newCostPrice, notes)
            _userMessage.value = "Stock updated successfully."
            refreshFinancialReport()
        }
    }

    // Customer Debt Operations
    fun saveCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.saveCustomer(customer)
            _userMessage.value = "Customer '${customer.name}' saved."
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            _userMessage.value = "Customer '${customer.name}' removed."
        }
    }

    fun recordDebtRepayment(customerId: Long, amount: Double, paymentMethod: String, notes: String) {
        viewModelScope.launch {
            val res = repository.repayDebt(customerId, amount, paymentMethod, notes)
            res.onSuccess {
                _userMessage.value = "Repayment of P${String.format(java.util.Locale.US, "%.2f", amount)} recorded."
                refreshFinancialReport()
            }.onFailure { err ->
                _userMessage.value = "Error: ${err.message}"
            }
        }
    }

    // Expenses
    fun saveExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.saveExpense(expense)
            _userMessage.value = "Expense '${expense.description}' recorded."
            refreshFinancialReport()
        }
    }

    fun reverseExpense(expenseId: Long, reason: String) {
        viewModelScope.launch {
            repository.reverseExpense(expenseId, reason)
            _userMessage.value = "Expense reversed."
            refreshFinancialReport()
        }
    }

    // Settings
    fun saveSettings(settings: ShopSettingsEntity) {
        viewModelScope.launch {
            repository.updateSettings(settings)
            _userMessage.value = "Shop settings updated."
        }
    }

    fun resetToSampleData() {
        viewModelScope.launch {
            repository.resetToSampleData()
            _userMessage.value = "Loaded realistic Botswana sample shop data."
            refreshFinancialReport()
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getInstance(application)
                    val repo = ShopRepository(db)
                    return ShopViewModel(application, repo) as T
                }
            }
        }
    }
}
