package com.example.ui.screens.stock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.StockMovementEntity
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.BwGold
import com.example.ui.theme.BwGreenSuccess
import com.example.ui.theme.BwRedDanger
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val STOCK_UNITS = listOf("pcs", "kg", "L", "pkts")

@Composable
fun StockScreen(
    products: List<ProductEntity>,
    movements: List<StockMovementEntity>,
    currencySymbol: String,
    onSaveProduct: (ProductEntity) -> Unit,
    onDeleteProduct: (ProductEntity) -> Unit,
    onRestock: (Long, Double, Double?, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    // Dialog states
    var productToEdit by remember { mutableStateOf<ProductEntity?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }
    var productToRestock by remember { mutableStateOf<ProductEntity?>(null) }
    var productToDelete by remember { mutableStateOf<ProductEntity?>(null) }
    var showMovementHistory by remember { mutableStateOf(false) }

    val filteredProducts = remember(products, searchQuery, filterLowStockOnly) {
        products.filter { p ->
            val matchesSearch = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.skuOrBarcode.contains(searchQuery, ignoreCase = true) ||
                    p.category.contains(searchQuery, ignoreCase = true)
            val matchesLowStock = !filterLowStockOnly || (p.quantity <= p.minStockLevel)
            matchesSearch && matchesLowStock
        }
    }

    val totalValuation = remember(products) {
        products.sumOf { it.quantity * it.buyingPrice }
    }
    val lowStockCount = remember(products) {
        products.count { it.quantity <= it.minStockLevel }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Inventory Summary Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Stock Cost Valuation", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            CurrencyFormatter.format(totalValuation, currencySymbol),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = BwBluePrimary
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (lowStockCount > 0) Color(0xFFFEF3C7) else Color(0xFFD1FAE5),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (lowStockCount > 0) "$lowStockCount Low Stock" else "Stock Healthy",
                                color = if (lowStockCount > 0) Color(0xFFB45309) else Color(0xFF047857),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { showMovementHistory = true },
                            modifier = Modifier.testTag("stock_history_button")
                        ) {
                            Icon(Icons.Default.History, contentDescription = "Stock Movement History", tint = BwBluePrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stock_search_input"),
                placeholder = { Text("Search product, barcode or category...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BwBluePrimary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Filter chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !filterLowStockOnly,
                    onClick = { filterLowStockOnly = false },
                    label = { Text("All Products (${products.size})") }
                )
                FilterChip(
                    selected = filterLowStockOnly,
                    onClick = { filterLowStockOnly = true },
                    label = { Text("Low Stock Only ($lowStockCount)") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Product List
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No products match the filter", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductStockCard(
                            product = product,
                            currencySymbol = currencySymbol,
                            onEdit = { productToEdit = product },
                            onRestock = { productToRestock = product },
                            onDelete = { productToDelete = product }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp)) // Space for FAB
                    }
                }
            }
        }

        // FAB to Add Product
        FloatingActionButton(
            onClick = { isCreatingNew = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_product_fab"),
            containerColor = BwBluePrimary,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add New Product")
        }
    }

    // Add / Edit Product Dialog
    if (isCreatingNew || productToEdit != null) {
        ProductEditDialog(
            product = productToEdit,
            currencySymbol = currencySymbol,
            onDismiss = {
                isCreatingNew = false
                productToEdit = null
            },
            onSave = {
                onSaveProduct(it)
                isCreatingNew = false
                productToEdit = null
            }
        )
    }

    // Restock Dialog
    if (productToRestock != null) {
        RestockDialog(
            product = productToRestock!!,
            currencySymbol = currencySymbol,
            onDismiss = { productToRestock = null },
            onConfirm = { addedQty, newCost, notes ->
                onRestock(productToRestock!!.id, addedQty, newCost, notes)
                productToRestock = null
            }
        )
    }

    // Delete Confirmation
    if (productToDelete != null) {
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("Delete Product?") },
            text = { Text("Are you sure you want to delete '${productToDelete!!.name}'? This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProduct(productToDelete!!)
                        productToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BwRedDanger)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Movement History Dialog
    if (showMovementHistory) {
        StockMovementHistoryDialog(
            movements = movements,
            currencySymbol = currencySymbol,
            onDismiss = { showMovementHistory = false }
        )
    }
}

@Composable
private fun ProductStockCard(
    product: ProductEntity,
    currencySymbol: String,
    onEdit: () -> Unit,
    onRestock: () -> Unit,
    onDelete: () -> Unit
) {
    val margin = if (product.sellingPrice > 0.0) {
        ((product.sellingPrice - product.buyingPrice) / product.sellingPrice) * 100.0
    } else 0.0

    val isOutOfStock = product.quantity <= 0.0
    val isLowStock = product.quantity <= product.minStockLevel && !isOutOfStock

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        text = "${product.category} • SKU/Barcode: ${if (product.skuOrBarcode.isBlank()) "None" else product.skuOrBarcode}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status Badge
                val (badgeText, badgeBg, badgeTextColor) = when {
                    isOutOfStock -> Triple("OUT OF STOCK", Color(0xFFFEE2E2), Color(0xFFDC2626))
                    isLowStock -> Triple("LOW STOCK", Color(0xFFFEF3C7), Color(0xFFD97706))
                    else -> Triple("IN STOCK", Color(0xFFD1FAE5), Color(0xFF059669))
                }
                Surface(color = badgeBg, shape = RoundedCornerShape(4.dp)) {
                    Text(
                        text = badgeText,
                        color = badgeTextColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing & Stock metrics row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Stock Level", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val qtyStr = if (product.quantity % 1.0 == 0.0) product.quantity.toInt().toString() else product.quantity.toString()
                    Text(
                        text = "$qtyStr ${product.unit}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (isLowStock || isOutOfStock) BwRedDanger else MaterialTheme.colorScheme.onSurface
                    )
                }

                Column {
                    Text("Cost Price", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(product.buyingPrice, currencySymbol), fontSize = 12.sp)
                }

                Column {
                    Text("Selling Price", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(CurrencyFormatter.format(product.sellingPrice, currencySymbol), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BwBluePrimary)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Margin", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        String.format(Locale.US, "%.1f%%", margin),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (margin >= 0) BwGreenSuccess else BwRedDanger
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(4.dp))

            // Quick Actions: Restock, Edit, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onRestock) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Restock")
                }
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Product", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Product", tint = Color.Gray, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
private fun ProductEditDialog(
    product: ProductEntity?,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var skuOrBarcode by remember { mutableStateOf(product?.skuOrBarcode ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Groceries") }
    var buyingPriceText by remember { mutableStateOf(product?.let { String.format(Locale.US, "%.2f", it.buyingPrice) } ?: "") }
    var sellingPriceText by remember { mutableStateOf(product?.let { String.format(Locale.US, "%.2f", it.sellingPrice) } ?: "") }
    var quantityText by remember { mutableStateOf(product?.let { if (it.quantity % 1.0 == 0.0) it.quantity.toInt().toString() else it.quantity.toString() } ?: "10") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
    var minStockText by remember { mutableStateOf(product?.minStockLevel?.toInt()?.toString() ?: "5") }
    var formError by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (product == null) "Add New Product" else "Edit Product",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; formError = null },
                    label = { Text("Product Name *") },
                    placeholder = { Text("e.g. White Star Maize Meal 5kg") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_name_input"),
                    isError = formError != null && name.isBlank()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        placeholder = { Text("Groceries") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = skuOrBarcode,
                        onValueChange = { skuOrBarcode = it },
                        label = { Text("Barcode / SKU") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = buyingPriceText,
                        onValueChange = { buyingPriceText = it },
                        label = { Text("Cost Price ($currencySymbol) *") },
                        placeholder = { Text("40.00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("product_cost_price_input")
                    )
                    OutlinedTextField(
                        value = sellingPriceText,
                        onValueChange = { sellingPriceText = it },
                        label = { Text("Selling Price ($currencySymbol) *") },
                        placeholder = { Text("49.50") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("product_selling_price_input")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity in Stock *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("product_quantity_input")
                    )
                    OutlinedTextField(
                        value = minStockText,
                        onValueChange = { minStockText = it },
                        label = { Text("Min Stock Alert") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Unit of Measure", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    STOCK_UNITS.forEach { u ->
                        FilterChip(
                            selected = unit == u,
                            onClick = { unit = u },
                            label = { Text(u) }
                        )
                    }
                }

                if (formError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(formError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (name.isBlank()) {
                            formError = "Please enter product name"
                            return@Button
                        }
                        val cost = buyingPriceText.toDoubleOrNull() ?: 0.0
                        val selling = sellingPriceText.toDoubleOrNull() ?: 0.0
                        val qty = quantityText.toDoubleOrNull() ?: 0.0
                        val minStock = minStockText.toDoubleOrNull() ?: 5.0

                        val toSave = (product ?: ProductEntity(name = "")).copy(
                            name = name.trim(),
                            skuOrBarcode = skuOrBarcode.trim(),
                            category = if (category.isBlank()) "General" else category.trim(),
                            buyingPrice = cost,
                            sellingPrice = selling,
                            quantity = qty,
                            unit = unit,
                            minStockLevel = minStock,
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(toSave)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_product_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
                ) {
                    Text("Save Product", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RestockDialog(
    product: ProductEntity,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (addedQty: Double, newCost: Double?, notes: String) -> Unit
) {
    var addedQtyText by remember { mutableStateOf("10") }
    var newCostText by remember { mutableStateOf(String.format(Locale.US, "%.2f", product.buyingPrice)) }
    var notesText by remember { mutableStateOf("Wholesale restocking") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Restock: ${product.name}") },
        text = {
            Column {
                Text("Current Stock: ${product.quantity} ${product.unit}")
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = addedQtyText,
                    onValueChange = { addedQtyText = it },
                    label = { Text("Quantity to Add (${product.unit})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = newCostText,
                    onValueChange = { newCostText = it },
                    label = { Text("Cost Price per Unit ($currencySymbol)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Supplier / Invoice Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val added = addedQtyText.toDoubleOrNull() ?: 0.0
                    val cost = newCostText.toDoubleOrNull()
                    if (added > 0.0) {
                        onConfirm(added, cost, notesText)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BwBluePrimary)
            ) {
                Text("Confirm Restock")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun StockMovementHistoryDialog(
    movements: List<StockMovementEntity>,
    currencySymbol: String,
    onDismiss: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.US) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .height(600.dp)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Stock Movement Audit Trail", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (movements.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No stock movements recorded yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(movements, key = { it.id }) { m ->
                            val isPositive = m.quantityChange > 0
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(m.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            "${dateFormat.format(Date(m.timestamp))} • ${m.type} • ${m.notes}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            "Qty: ${m.previousQuantity} -> ${m.newQuantity}",
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        text = "${if (isPositive) "+" else ""}${m.quantityChange}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (isPositive) BwGreenSuccess else BwRedDanger
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
