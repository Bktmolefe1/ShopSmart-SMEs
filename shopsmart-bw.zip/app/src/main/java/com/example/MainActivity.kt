package com.example

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.customers.CustomersScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.expenses.ExpensesDialog
import com.example.ui.screens.receipt.ReceiptDialog
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.sales.SalesPosScreen
import com.example.ui.screens.settings.SettingsDialog
import com.example.ui.screens.stock.StockScreen
import com.example.ui.theme.BwBluePrimary
import com.example.ui.theme.ShopSmartTheme
import com.example.ui.viewmodel.ShopViewModel
import kotlinx.coroutines.launch

enum class AppTab(val title: String) {
    HOME("Home"),
    SALES("Sales"),
    STOCK("Stock"),
    CUSTOMERS("Customers"),
    REPORTS("Reports")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShopSmartTheme {
                ShopSmartApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopSmartApp() {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val viewModel: ShopViewModel = viewModel(factory = ShopViewModel.provideFactory(application))

    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val lowStockProducts by viewModel.lowStockProducts.collectAsStateWithLifecycle()
    val lowStockCount by viewModel.lowStockCount.collectAsStateWithLifecycle()
    val customers by viewModel.allCustomers.collectAsStateWithLifecycle()
    val totalDebt by viewModel.totalOutstandingDebt.collectAsStateWithLifecycle()
    val recentSales by viewModel.recentSales.collectAsStateWithLifecycle()
    val allSales by viewModel.allSales.collectAsStateWithLifecycle()
    val allExpenses by viewModel.allExpenses.collectAsStateWithLifecycle()
    val allStockMovements by viewModel.allStockMovements.collectAsStateWithLifecycle()
    val shopSettings by viewModel.shopSettings.collectAsStateWithLifecycle()

    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartDiscount by viewModel.cartDiscountAmount.collectAsStateWithLifecycle()
    val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()

    val selectedPeriod by viewModel.selectedPeriod.collectAsStateWithLifecycle()
    val financialReport by viewModel.financialReport.collectAsStateWithLifecycle()
    val lastCompletedSale by viewModel.lastCompletedSale.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(AppTab.HOME) }
    var showExpensesDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Handle user messages
    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    // Predictive back / Back navigation
    BackHandler(enabled = currentTab != AppTab.HOME) {
        currentTab = AppTab.HOME
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    androidx.compose.foundation.layout.Column {
                        Text(
                            text = shopSettings.businessName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1
                        )
                        Text(
                            text = "ShopSmart BW • Botswana Pula (${shopSettings.currencySymbol})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showExpensesDialog = true },
                        modifier = Modifier.testTag("top_app_bar_expenses_button")
                    ) {
                        Icon(Icons.Default.MoneyOff, contentDescription = "Expenses", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("top_app_bar_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                // 1. Home
                NavigationBarItem(
                    selected = currentTab == AppTab.HOME,
                    onClick = { currentTab = AppTab.HOME },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_home")
                )

                // 2. Sales / POS
                NavigationBarItem(
                    selected = currentTab == AppTab.SALES,
                    onClick = { currentTab = AppTab.SALES },
                    icon = {
                        if (cartItems.isNotEmpty()) {
                            BadgedBox(badge = {
                                Badge(containerColor = Color(0xFFD97706)) {
                                    Text(cartItems.size.toString())
                                }
                            }) {
                                Icon(Icons.Default.PointOfSale, contentDescription = "Sales")
                            }
                        } else {
                            Icon(Icons.Default.PointOfSale, contentDescription = "Sales")
                        }
                    },
                    label = { Text("Sales", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_sales")
                )

                // 3. Stock
                NavigationBarItem(
                    selected = currentTab == AppTab.STOCK,
                    onClick = { currentTab = AppTab.STOCK },
                    icon = {
                        if (lowStockCount > 0) {
                            BadgedBox(badge = {
                                Badge(containerColor = Color(0xFFDC2626)) {
                                    Text(lowStockCount.toString())
                                }
                            }) {
                                Icon(Icons.Default.Inventory, contentDescription = "Stock")
                            }
                        } else {
                            Icon(Icons.Default.Inventory, contentDescription = "Stock")
                        }
                    },
                    label = { Text("Stock", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_stock")
                )

                // 4. Customers
                NavigationBarItem(
                    selected = currentTab == AppTab.CUSTOMERS,
                    onClick = { currentTab = AppTab.CUSTOMERS },
                    icon = {
                        if (totalDebt > 0.0) {
                            BadgedBox(badge = {
                                Badge(containerColor = Color(0xFFDC2626)) {
                                    Text("!")
                                }
                            }) {
                                Icon(Icons.Default.People, contentDescription = "Customers")
                            }
                        } else {
                            Icon(Icons.Default.People, contentDescription = "Customers")
                        }
                    },
                    label = { Text("Customers", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_customers")
                )

                // 5. Reports
                NavigationBarItem(
                    selected = currentTab == AppTab.REPORTS,
                    onClick = { currentTab = AppTab.REPORTS },
                    icon = { Icon(Icons.Default.Assessment, contentDescription = "Reports") },
                    label = { Text("Reports", fontSize = 11.sp) },
                    modifier = Modifier.testTag("tab_reports")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.HOME -> {
                    DashboardScreen(
                        report = financialReport,
                        selectedPeriod = selectedPeriod,
                        settings = shopSettings,
                        lowStockProducts = lowStockProducts,
                        recentSales = recentSales,
                        onSelectPeriod = { viewModel.setDateFilterPeriod(it) },
                        onNavigateToSales = { currentTab = AppTab.SALES },
                        onNavigateToStock = { currentTab = AppTab.STOCK },
                        onNavigateToCustomers = { currentTab = AppTab.CUSTOMERS },
                        onOpenExpensesDialog = { showExpensesDialog = true },
                        onCancelSale = { saleId, reason -> viewModel.cancelSale(saleId, reason) }
                    )
                }

                AppTab.SALES -> {
                    SalesPosScreen(
                        products = products,
                        customers = customers,
                        cartItems = cartItems,
                        discountAmount = cartDiscount,
                        selectedCustomer = selectedCustomer,
                        settings = shopSettings,
                        onAddToCart = { viewModel.addToCart(it) },
                        onUpdateCartQuantity = { id, qty -> viewModel.updateCartItemQuantity(id, qty) },
                        onRemoveFromCart = { viewModel.removeFromCart(it) },
                        onSetDiscount = { viewModel.setCartDiscount(it) },
                        onSelectCustomer = { viewModel.setSelectedCustomer(it) },
                        onCheckout = { method, paid, credit, split, notes ->
                            viewModel.checkout(method, paid, credit, split, notes)
                        },
                        onClearCart = { viewModel.clearCart() }
                    )
                }

                AppTab.STOCK -> {
                    StockScreen(
                        products = products,
                        movements = allStockMovements,
                        currencySymbol = shopSettings.currencySymbol,
                        onSaveProduct = { viewModel.saveProduct(it) },
                        onDeleteProduct = { viewModel.deleteProduct(it) },
                        onRestock = { id, added, cost, notes -> viewModel.restockProduct(id, added, cost, notes) }
                    )
                }

                AppTab.CUSTOMERS -> {
                    CustomersScreen(
                        customers = customers,
                        settings = shopSettings,
                        onSaveCustomer = { viewModel.saveCustomer(it) },
                        onDeleteCustomer = { viewModel.deleteCustomer(it) },
                        onRecordRepayment = { id, amt, meth, notes ->
                            viewModel.recordDebtRepayment(id, amt, meth, notes)
                        }
                    )
                }

                AppTab.REPORTS -> {
                    ReportsScreen(
                        report = financialReport,
                        selectedPeriod = selectedPeriod,
                        settings = shopSettings,
                        products = products,
                        sales = allSales,
                        customers = customers,
                        expenses = allExpenses,
                        onSelectPeriod = { viewModel.setDateFilterPeriod(it) }
                    )
                }
            }
        }
    }

    // Receipt Dialog on sale completion
    if (lastCompletedSale != null) {
        val (sale, items) = lastCompletedSale!!
        ReceiptDialog(
            settings = shopSettings,
            sale = sale,
            items = items,
            onDismiss = { viewModel.dismissReceiptDialog() }
        )
    }

    // Expenses Dialog
    if (showExpensesDialog) {
        ExpensesDialog(
            expenses = allExpenses,
            currencySymbol = shopSettings.currencySymbol,
            onSaveExpense = { viewModel.saveExpense(it) },
            onReverseExpense = { id, reason -> viewModel.reverseExpense(id, reason) },
            onDismiss = { showExpensesDialog = false }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            settings = shopSettings,
            onSaveSettings = { viewModel.saveSettings(it) },
            onResetToSampleData = { viewModel.resetToSampleData() },
            onExportBackup = {
                coroutineScope.launch {
                    val db = com.example.data.local.AppDatabase.getInstance(context)
                    val repo = com.example.data.repository.ShopRepository(db)
                    val json = repo.exportBackupJson()
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "ShopSmart_BW_Backup.json")
                        putExtra(Intent.EXTRA_TEXT, json)
                    }
                    context.startActivity(Intent.createChooser(intent, "Export ShopSmart Backup"))
                }
            },
            onImportBackup = { json ->
                coroutineScope.launch {
                    val db = com.example.data.local.AppDatabase.getInstance(context)
                    val repo = com.example.data.repository.ShopRepository(db)
                    val res = repo.importBackupJson(json)
                    res.onSuccess { count ->
                        Toast.makeText(context, "Restored $count records successfully!", Toast.LENGTH_SHORT).show()
                        viewModel.refreshFinancialReport()
                    }.onFailure { err ->
                        Toast.makeText(context, "Import failed: ${err.message}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onDismiss = { showSettingsDialog = false }
        )
    }
}
