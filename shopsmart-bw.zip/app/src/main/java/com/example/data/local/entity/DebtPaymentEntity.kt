package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "debt_payments",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId"), Index("saleId")]
)
data class DebtPaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val saleId: Long? = null,
    val amount: Double,
    val paymentMethod: String = "CASH", // CASH, ORANGE_MONEY, SMEGA, MYZAKA, CARD
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
