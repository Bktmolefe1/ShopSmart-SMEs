package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val skuOrBarcode: String = "",
    val category: String = "General",
    val buyingPrice: Double = 0.0, // Cost price in BWP
    val sellingPrice: Double = 0.0, // Selling price in BWP
    val quantity: Double = 0.0, // Current stock on hand
    val unit: String = "pcs", // "pcs", "kg", "L", "pkts"
    val minStockLevel: Double = 5.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
