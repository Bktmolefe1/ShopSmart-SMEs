package com.example.data.local

import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShopSettingsEntity

object SampleData {
    val initialSettings = ShopSettingsEntity(
        id = 1,
        businessName = "ShopSmart General Dealer",
        phone = "+267 72 123 456",
        address = "Plot 1042, Extension 2, Gaborone, Botswana",
        currencySymbol = "P",
        receiptFooter = "Ke a leboga! Thank you for supporting our local business.",
        lowStockThresholdDefault = 5.0,
        pinCode = "",
        allowNegativeStock = false
    )

    val sampleProducts = listOf(
        ProductEntity(
            id = 1,
            name = "White Star Super Maize Meal 5kg",
            skuOrBarcode = "6001007001",
            category = "Groceries",
            buyingPrice = 40.00,
            sellingPrice = 49.50,
            quantity = 22.0,
            unit = "pcs",
            minStockLevel = 5.0
        ),
        ProductEntity(
            id = 2,
            name = "White Star Super Maize Meal 10kg",
            skuOrBarcode = "6001007002",
            category = "Groceries",
            buyingPrice = 78.00,
            sellingPrice = 95.00,
            quantity = 14.0,
            unit = "pcs",
            minStockLevel = 4.0
        ),
        ProductEntity(
            id = 3,
            name = "Tastic Parboiled Rice 2kg",
            skuOrBarcode = "6001007003",
            category = "Groceries",
            buyingPrice = 31.50,
            sellingPrice = 39.00,
            quantity = 18.0,
            unit = "pcs",
            minStockLevel = 5.0
        ),
        ProductEntity(
            id = 4,
            name = "Sunfoil Pure Sunflower Cooking Oil 2L",
            skuOrBarcode = "6001007004",
            category = "Groceries",
            buyingPrice = 34.00,
            sellingPrice = 42.50,
            quantity = 20.0,
            unit = "pcs",
            minStockLevel = 6.0
        ),
        ProductEntity(
            id = 5,
            name = "Huletts White Sugar 2kg",
            skuOrBarcode = "6001007005",
            category = "Groceries",
            buyingPrice = 28.00,
            sellingPrice = 35.00,
            quantity = 25.0,
            unit = "pcs",
            minStockLevel = 6.0
        ),
        ProductEntity(
            id = 6,
            name = "Stoney Ginger Beer 330ml Can",
            skuOrBarcode = "6001007006",
            category = "Beverages",
            buyingPrice = 6.20,
            sellingPrice = 8.50,
            quantity = 48.0,
            unit = "pcs",
            minStockLevel = 12.0
        ),
        ProductEntity(
            id = 7,
            name = "Coca-Cola Original 2L Bottle",
            skuOrBarcode = "6001007007",
            category = "Beverages",
            buyingPrice = 16.50,
            sellingPrice = 22.00,
            quantity = 16.0,
            unit = "pcs",
            minStockLevel = 6.0
        ),
        ProductEntity(
            id = 8,
            name = "Fresh White Bread Loaf",
            skuOrBarcode = "6001007008",
            category = "Bakery",
            buyingPrice = 9.50,
            sellingPrice = 12.50,
            quantity = 3.0, // Low stock trigger
            unit = "pcs",
            minStockLevel = 5.0
        ),
        ProductEntity(
            id = 9,
            name = "Large Farm Eggs (1 Dozen)",
            skuOrBarcode = "6001007009",
            category = "Dairy & Eggs",
            buyingPrice = 24.00,
            sellingPrice = 32.00,
            quantity = 2.0, // Low stock trigger
            unit = "pkts",
            minStockLevel = 5.0
        ),
        ProductEntity(
            id = 10,
            name = "Sunlight Laundry Soap Bar 500g",
            skuOrBarcode = "6001007010",
            category = "Cleaning",
            buyingPrice = 12.00,
            sellingPrice = 16.00,
            quantity = 30.0,
            unit = "pcs",
            minStockLevel = 8.0
        ),
        ProductEntity(
            id = 11,
            name = "Chappies Bubblegum (Assorted)",
            skuOrBarcode = "6001007011",
            category = "Confectionery",
            buyingPrice = 0.30,
            sellingPrice = 0.50,
            quantity = 180.0,
            unit = "pcs",
            minStockLevel = 50.0
        ),
        ProductEntity(
            id = 12,
            name = "Mascom Airtime P10 Voucher",
            skuOrBarcode = "6001007012",
            category = "Airtime",
            buyingPrice = 9.50,
            sellingPrice = 10.00,
            quantity = 50.0,
            unit = "pcs",
            minStockLevel = 10.0
        ),
        ProductEntity(
            id = 13,
            name = "Orange Airtime P10 Voucher",
            skuOrBarcode = "6001007013",
            category = "Airtime",
            buyingPrice = 9.50,
            sellingPrice = 10.00,
            quantity = 40.0,
            unit = "pcs",
            minStockLevel = 10.0
        )
    )

    val sampleCustomers = listOf(
        CustomerEntity(
            id = 1,
            name = "Lesego Tau",
            phone = "+267 71 234 567",
            totalDebt = 85.00,
            totalPaid = 120.00,
            notes = "Lives near community kgotla. Regularly pays at month-end."
        ),
        CustomerEntity(
            id = 2,
            name = "Kabo Molefe",
            phone = "+267 72 345 678",
            totalDebt = 145.00,
            totalPaid = 300.00,
            notes = "Local builder, takes building groceries and airtime."
        ),
        CustomerEntity(
            id = 3,
            name = "Neo Modise",
            phone = "+267 74 567 890",
            totalDebt = 0.00,
            totalPaid = 250.00,
            notes = "Always settles in cash or Orange Money."
        ),
        CustomerEntity(
            id = 4,
            name = "Tshepo Kgosi",
            phone = "+267 76 789 012",
            totalDebt = 48.50,
            totalPaid = 50.00,
            notes = "Took 5kg maize meal on credit."
        )
    )

    val sampleExpenses = listOf(
        ExpenseEntity(
            id = 1,
            category = "Rent",
            amount = 850.00,
            paymentMethod = "CASH",
            description = "Monthly tuckshop room rental",
            supplierOrRecipient = "Landlord Rre Phiri",
            date = System.currentTimeMillis() - 86400000L * 2
        ),
        ExpenseEntity(
            id = 2,
            category = "Electricity",
            amount = 150.00,
            paymentMethod = "ORANGE_MONEY",
            description = "BPC Prepaid electricity voucher token",
            supplierOrRecipient = "Botswana Power Corporation",
            date = System.currentTimeMillis() - 86400000L * 1
        ),
        ExpenseEntity(
            id = 3,
            category = "Transport",
            amount = 80.00,
            paymentMethod = "CASH",
            description = "Combi / transport fare to G-West wholesale",
            supplierOrRecipient = "Combi Driver",
            date = System.currentTimeMillis() - 3600000L * 4
        )
    )
}
