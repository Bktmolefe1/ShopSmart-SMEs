package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // Rent, Electricity, Transport, Wages, Internet, Repairs, Misc
    val amount: Double,
    val paymentMethod: String = "CASH",
    val description: String,
    val supplierOrRecipient: String = "",
    val date: Long = System.currentTimeMillis(),
    val isReversed: Boolean = false,
    val reversalReason: String = ""
)
