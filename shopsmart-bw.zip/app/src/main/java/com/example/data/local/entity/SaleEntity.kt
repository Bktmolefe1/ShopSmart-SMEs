package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class SaleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptNumber: String,
    val subtotal: Double,
    val discountAmount: Double = 0.0,
    val totalAmount: Double, // Recognized sales revenue
    val totalCostOfGoodsSold: Double, // COGS calculated at sale time
    val amountPaid: Double, // Cash/Electronic received at checkout
    val creditAmount: Double = 0.0, // Unpaid amount added to Accounts Receivable
    val paymentMethod: String, // CASH, ORANGE_MONEY, SMEGA, MYZAKA, CARD, CREDIT, SPLIT
    val splitDetails: String = "",
    val customerId: Long? = null,
    val customerName: String? = null,
    val customerPhone: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "COMPLETED", // COMPLETED, CANCELLED, REFUNDED
    val notes: String = ""
)
