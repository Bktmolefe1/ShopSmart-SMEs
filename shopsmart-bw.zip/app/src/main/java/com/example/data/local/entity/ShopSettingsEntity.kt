package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shop_settings")
data class ShopSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val businessName: String = "ShopSmart General Dealer",
    val phone: String = "+267 72 123 456",
    val address: String = "Plot 1042, Extension 2, Gaborone, Botswana",
    val currencySymbol: String = "P",
    val receiptFooter: String = "Ke a leboga! Thank you for your business.",
    val lowStockThresholdDefault: Double = 5.0,
    val pinCode: String = "", // Optional PIN protection
    val allowNegativeStock: Boolean = false
)
