package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.SampleData
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.DebtPaymentEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.StockMovementEntity
import com.example.domain.model.CartItem
import com.example.domain.model.FinancialReportSummary
import com.example.domain.model.TopProductItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShopRepository(private val db: AppDatabase) {
    val allProducts: Flow<List<ProductEntity>> = db.productDao().getAllProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = db.productDao().getLowStockProducts()
    val lowStockCount: Flow<Int> = db.productDao().getLowStockCountFlow()
    val totalStockCostValue: Flow<Double?> = db.productDao().getTotalStockCostValueFlow()

    val allCustomers: Flow<List<CustomerEntity>> = db.customerDao().getAllCustomers()
    val customersWithDebt: Flow<List<CustomerEntity>> = db.customerDao().getCustomersWithDebt()
    val totalOutstandingDebt: Flow<Double?> = db.customerDao().getTotalOutstandingDebtFlow()

    val recentSales: Flow<List<SaleEntity>> = db.saleDao().getRecentSales(25)
    val allSales: Flow<List<SaleEntity>> = db.saleDao().getAllSales()
    val allExpenses: Flow<List<ExpenseEntity>> = db.expenseDao().getAllExpenses()
    val allStockMovements: Flow<List<StockMovementEntity>> = db.stockMovementDao().getAllMovements()
    val shopSettings: Flow<ShopSettingsEntity?> = db.shopSettingsDao().getSettingsFlow()

    fun searchProducts(query: String): Flow<List<ProductEntity>> = db.productDao().searchProducts(query)

    suspend fun getSettings(): ShopSettingsEntity {
        return db.shopSettingsDao().getSettingsSync() ?: SampleData.initialSettings
    }

    suspend fun updateSettings(settings: ShopSettingsEntity) {
        db.shopSettingsDao().insertOrUpdate(settings)
    }

    suspend fun saveProduct(product: ProductEntity): Long {
        return if (product.id == 0L) {
            val id = db.productDao().insertProduct(product)
            db.stockMovementDao().insertMovement(
                StockMovementEntity(
                    productId = id,
                    productName = product.name,
                    type = "ADJUSTMENT",
                    quantityChange = product.quantity,
                    previousQuantity = 0.0,
                    newQuantity = product.quantity,
                    unitCost = product.buyingPrice,
                    notes = "Initial stock entry"
                )
            )
            id
        } else {
            val old = db.productDao().getProductById(product.id)
            db.productDao().updateProduct(product)
            if (old != null && old.quantity != product.quantity) {
                val diff = product.quantity - old.quantity
                db.stockMovementDao().insertMovement(
                    StockMovementEntity(
                        productId = product.id,
                        productName = product.name,
                        type = "ADJUSTMENT",
                        quantityChange = diff,
                        previousQuantity = old.quantity,
                        newQuantity = product.quantity,
                        unitCost = product.buyingPrice,
                        notes = "Manual stock update"
                    )
                )
            }
            product.id
        }
    }

    suspend fun deleteProduct(product: ProductEntity) {
        db.productDao().deleteProduct(product)
    }

    suspend fun restockProduct(productId: Long, addedQty: Double, newCostPrice: Double?, notes: String) {
        db.withTransaction {
            val product = db.productDao().getProductById(productId) ?: return@withTransaction
            val newQty = product.quantity + addedQty
            val updated = product.copy(
                quantity = newQty,
                buyingPrice = newCostPrice ?: product.buyingPrice,
                updatedAt = System.currentTimeMillis()
            )
            db.productDao().updateProduct(updated)
            db.stockMovementDao().insertMovement(
                StockMovementEntity(
                    productId = productId,
                    productName = product.name,
                    type = "PURCHASE",
                    quantityChange = addedQty,
                    previousQuantity = product.quantity,
                    newQuantity = newQty,
                    unitCost = newCostPrice ?: product.buyingPrice,
                    notes = if (notes.isBlank()) "Stock restocking" else notes
                )
            )
        }
    }

    suspend fun saveCustomer(customer: CustomerEntity): Long {
        return if (customer.id == 0L) {
            db.customerDao().insertCustomer(customer)
        } else {
            db.customerDao().updateCustomer(customer)
            customer.id
        }
    }

    suspend fun deleteCustomer(customer: CustomerEntity) {
        db.customerDao().deleteCustomer(customer)
    }

    suspend fun repayDebt(customerId: Long, amount: Double, paymentMethod: String, notes: String): Result<DebtPaymentEntity> {
        return db.withTransaction {
            val customer = db.customerDao().getCustomerById(customerId)
                ?: return@withTransaction Result.failure(Exception("Customer not found"))

            val actualAmount = amount.coerceAtMost(customer.totalDebt)
            if (actualAmount <= 0.0) {
                return@withTransaction Result.failure(Exception("Repayment must be greater than P0.00"))
            }

            val payment = DebtPaymentEntity(
                customerId = customerId,
                amount = actualAmount,
                paymentMethod = paymentMethod,
                timestamp = System.currentTimeMillis(),
                notes = notes
            )
            val paymentId = db.saleDao().insertDebtPayment(payment)
            db.customerDao().adjustCustomerBalance(
                customerId = customerId,
                debtDelta = -actualAmount,
                paidDelta = actualAmount
            )
            Result.success(payment.copy(id = paymentId))
        }
    }

    suspend fun completeSale(
        cartItems: List<CartItem>,
        discountAmount: Double,
        paymentMethod: String,
        amountPaid: Double,
        creditAmount: Double,
        splitDetails: String,
        customer: CustomerEntity?,
        notes: String
    ): Result<Pair<SaleEntity, List<SaleItemEntity>>> = withContext(Dispatchers.IO) {
        if (cartItems.isEmpty()) {
            return@withContext Result.failure(Exception("Cart is empty"))
        }

        val settings = getSettings()
        // Check negative stock constraints
        if (!settings.allowNegativeStock) {
            for (item in cartItems) {
                val current = db.productDao().getProductById(item.product.id)
                val available = current?.quantity ?: 0.0
                if (item.quantity > available) {
                    return@withContext Result.failure(
                        Exception("Insufficient stock for '${item.product.name}'. Available: $available, Cart: ${item.quantity}")
                    )
                }
            }
        }

        try {
            val result = db.withTransaction {
                val subtotal = cartItems.sumOf { it.finalSubtotal }
                val totalAmount = (subtotal - discountAmount).coerceAtLeast(0.0)
                val totalCogs = cartItems.sumOf { it.cogs }

                val datePrefix = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                val receiptNumber = "SSBW-$datePrefix-${(1000..9999).random()}"

                val sale = SaleEntity(
                    receiptNumber = receiptNumber,
                    subtotal = subtotal,
                    discountAmount = discountAmount,
                    totalAmount = totalAmount,
                    totalCostOfGoodsSold = totalCogs,
                    amountPaid = amountPaid,
                    creditAmount = creditAmount,
                    paymentMethod = paymentMethod,
                    splitDetails = splitDetails,
                    customerId = customer?.id,
                    customerName = customer?.name,
                    customerPhone = customer?.phone,
                    timestamp = System.currentTimeMillis(),
                    status = "COMPLETED",
                    notes = notes
                )

                val saleId = db.saleDao().insertSale(sale)
                val savedSale = sale.copy(id = saleId)

                val saleItems = cartItems.map { item ->
                    SaleItemEntity(
                        saleId = saleId,
                        productId = item.product.id,
                        productName = item.product.name,
                        quantity = item.quantity,
                        unit = item.product.unit,
                        unitCostPrice = item.product.buyingPrice,
                        unitSellingPrice = item.unitPrice,
                        subtotal = item.finalSubtotal
                    )
                }

                db.saleDao().insertSaleItems(saleItems)

                // Reduce stock and log movement
                for (item in cartItems) {
                    val current = db.productDao().getProductById(item.product.id)
                    val oldQty = current?.quantity ?: 0.0
                    val newQty = oldQty - item.quantity
                    db.productDao().updateQuantity(item.product.id, newQty)

                    db.stockMovementDao().insertMovement(
                        StockMovementEntity(
                            productId = item.product.id,
                            productName = item.product.name,
                            type = "SALE",
                            quantityChange = -item.quantity,
                            previousQuantity = oldQty,
                            newQuantity = newQty,
                            unitCost = item.product.buyingPrice,
                            notes = "Receipt $receiptNumber",
                            timestamp = System.currentTimeMillis()
                        )
                    )
                }

                // If credit sale, update customer debt
                if (creditAmount > 0.0 && customer != null) {
                    db.customerDao().adjustCustomerBalance(
                        customerId = customer.id,
                        debtDelta = creditAmount,
                        paidDelta = 0.0
                    )
                }

                Pair(savedSale, saleItems)
            }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSaleDetails(saleId: Long): Pair<SaleEntity, List<SaleItemEntity>>? {
        val sale = db.saleDao().getSaleById(saleId) ?: return null
        val items = db.saleDao().getSaleItems(saleId)
        return Pair(sale, items)
    }

    suspend fun cancelSale(saleId: Long, reason: String): Result<Unit> = withContext(Dispatchers.IO) {
        db.withTransaction {
            val sale = db.saleDao().getSaleById(saleId)
                ?: return@withTransaction Result.failure(Exception("Sale not found"))

            if (sale.status == "CANCELLED") {
                return@withTransaction Result.failure(Exception("Sale already cancelled"))
            }

            val items = db.saleDao().getSaleItems(saleId)

            // Restore stock
            for (item in items) {
                val current = db.productDao().getProductById(item.productId)
                val oldQty = current?.quantity ?: 0.0
                val newQty = oldQty + item.quantity
                db.productDao().updateQuantity(item.productId, newQty)

                db.stockMovementDao().insertMovement(
                    StockMovementEntity(
                        productId = item.productId,
                        productName = item.productName,
                        type = "RETURN",
                        quantityChange = item.quantity,
                        previousQuantity = oldQty,
                        newQuantity = newQty,
                        unitCost = item.unitCostPrice,
                        notes = "Cancelled Sale ${sale.receiptNumber}. Reason: $reason",
                        timestamp = System.currentTimeMillis()
                    )
                )
            }

            // Reverse customer debt if credit was extended
            if (sale.creditAmount > 0.0 && sale.customerId != null) {
                db.customerDao().adjustCustomerBalance(
                    customerId = sale.customerId,
                    debtDelta = -sale.creditAmount,
                    paidDelta = 0.0
                )
            }

            db.saleDao().updateSale(
                sale.copy(
                    status = "CANCELLED",
                    notes = "${sale.notes} [Cancelled: $reason]"
                )
            )

            Result.success(Unit)
        }
    }

    suspend fun saveExpense(expense: ExpenseEntity): Long {
        return if (expense.id == 0L) {
            db.expenseDao().insertExpense(expense)
        } else {
            db.expenseDao().updateExpense(expense)
            expense.id
        }
    }

    suspend fun reverseExpense(expenseId: Long, reason: String) {
        val expenses = db.expenseDao().getActiveExpensesBetweenSync(0L, Long.MAX_VALUE)
        val expense = expenses.find { it.id == expenseId } ?: return
        db.expenseDao().updateExpense(
            expense.copy(
                isReversed = true,
                reversalReason = reason
            )
        )
    }

    suspend fun calculateFinancialReport(startTime: Long, endTime: Long): FinancialReportSummary = withContext(Dispatchers.IO) {
        val sales = db.saleDao().getSalesBetweenSync(startTime, endTime).filter { it.status == "COMPLETED" }
        val expenses = db.expenseDao().getActiveExpensesBetweenSync(startTime, endTime)
        val debtPayments = db.saleDao().getDebtPaymentsBetweenSync(startTime, endTime)
        val stockMovements = db.stockMovementDao().getMovementsBetweenSync(startTime, endTime)

        val salesRevenue = sales.sumOf { it.totalAmount }
        val costOfGoodsSold = sales.sumOf { it.totalCostOfGoodsSold }
        val grossProfit = salesRevenue - costOfGoodsSold

        val operatingExpenses = expenses.sumOf { it.amount }
        val netOperatingProfit = grossProfit - operatingExpenses

        // Cash flow calculations:
        // Cash received at POS (amountPaid on non-credit portions) + debt repayments collected
        val posCashReceived = sales.sumOf { it.amountPaid }
        val debtRepaymentsCollected = debtPayments.sumOf { it.amount }
        val totalCashReceived = posCashReceived + debtRepaymentsCollected

        val creditSales = sales.sumOf { it.creditAmount }

        // Stock purchases recorded in the period
        val stockPurchasesCost = stockMovements.filter { it.type == "PURCHASE" }
            .sumOf { it.quantityChange * it.unitCost }

        // Cash Out = operating expenses + stock purchases paid
        val cashOutflow = operatingExpenses + stockPurchasesCost
        val netCashFlow = totalCashReceived - cashOutflow

        val outstandingDebt = db.customerDao().getTotalOutstandingDebtSync() ?: 0.0
        val stockValuation = db.productDao().getTotalStockCostValueSync() ?: 0.0

        // Best sellers in period
        val saleItems = db.saleDao().getCompletedSaleItemsBetween(startTime, endTime)
        val topProducts = saleItems.groupBy { it.productName }
            .map { (name, items) ->
                val qty = items.sumOf { it.quantity }
                val rev = items.sumOf { it.subtotal }
                val cogs = items.sumOf { it.quantity * it.unitCostPrice }
                TopProductItem(
                    productName = name,
                    quantitySold = qty,
                    revenue = rev,
                    profit = rev - cogs
                )
            }
            .sortedByDescending { it.revenue }
            .take(10)

        FinancialReportSummary(
            salesRevenue = salesRevenue,
            cashReceived = totalCashReceived,
            creditSales = creditSales,
            costOfGoodsSold = costOfGoodsSold,
            grossProfit = grossProfit,
            operatingExpenses = operatingExpenses,
            netOperatingProfit = netOperatingProfit,
            totalOutstandingDebt = outstandingDebt,
            totalStockValuationCost = stockValuation,
            stockPurchasesCost = stockPurchasesCost,
            debtRepaymentsCollected = debtRepaymentsCollected,
            netCashFlow = netCashFlow,
            salesCount = sales.size,
            topProducts = topProducts
        )
    }

    suspend fun resetToSampleData() = withContext(Dispatchers.IO) {
        db.withTransaction {
            db.productDao().deleteAllProducts()
            db.customerDao().deleteAllCustomers()
            db.saleDao().deleteAllSales()
            db.saleDao().deleteAllSaleItems()
            db.saleDao().deleteAllDebtPayments()
            db.expenseDao().deleteAllExpenses()
            db.stockMovementDao().deleteAllMovements()
            db.populateInitialData()
        }
    }

    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val products = db.productDao().getAllProductsSync()
        val customers = db.customerDao().getAllCustomersSync()
        val expenses = db.expenseDao().getActiveExpensesBetweenSync(0L, Long.MAX_VALUE)

        val prodArray = JSONArray()
        products.forEach { p ->
            val o = JSONObject()
            o.put("name", p.name)
            o.put("skuOrBarcode", p.skuOrBarcode)
            o.put("category", p.category)
            o.put("buyingPrice", p.buyingPrice)
            o.put("sellingPrice", p.sellingPrice)
            o.put("quantity", p.quantity)
            o.put("unit", p.unit)
            o.put("minStockLevel", p.minStockLevel)
            prodArray.put(o)
        }
        root.put("products", prodArray)

        val custArray = JSONArray()
        customers.forEach { c ->
            val o = JSONObject()
            o.put("name", c.name)
            o.put("phone", c.phone)
            o.put("totalDebt", c.totalDebt)
            o.put("totalPaid", c.totalPaid)
            o.put("notes", c.notes)
            custArray.put(o)
        }
        root.put("customers", custArray)

        val expArray = JSONArray()
        expenses.forEach { e ->
            val o = JSONObject()
            o.put("category", e.category)
            o.put("amount", e.amount)
            o.put("paymentMethod", e.paymentMethod)
            o.put("description", e.description)
            o.put("supplierOrRecipient", e.supplierOrRecipient)
            o.put("date", e.date)
            expArray.put(o)
        }
        root.put("expenses", expArray)

        root.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            var count = 0
            db.withTransaction {
                if (root.has("products")) {
                    val arr = root.getJSONArray("products")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        db.productDao().insertProduct(
                            ProductEntity(
                                name = o.getString("name"),
                                skuOrBarcode = o.optString("skuOrBarcode", ""),
                                category = o.optString("category", "General"),
                                buyingPrice = o.optDouble("buyingPrice", 0.0),
                                sellingPrice = o.optDouble("sellingPrice", 0.0),
                                quantity = o.optDouble("quantity", 0.0),
                                unit = o.optString("unit", "pcs"),
                                minStockLevel = o.optDouble("minStockLevel", 5.0)
                            )
                        )
                        count++
                    }
                }
                if (root.has("customers")) {
                    val arr = root.getJSONArray("customers")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        db.customerDao().insertCustomer(
                            CustomerEntity(
                                name = o.getString("name"),
                                phone = o.optString("phone", ""),
                                totalDebt = o.optDouble("totalDebt", 0.0),
                                totalPaid = o.optDouble("totalPaid", 0.0),
                                notes = o.optString("notes", "")
                            )
                        )
                        count++
                    }
                }
            }
            Result.success(count)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
