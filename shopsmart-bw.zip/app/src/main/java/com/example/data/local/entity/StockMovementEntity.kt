package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "stock_movements",
    indices = [Index("productId"), Index("timestamp")]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val type: String, // "PURCHASE", "SALE", "ADJUSTMENT", "RETURN"
    val quantityChange: Double, // positive or negative
    val previousQuantity: Double,
    val newQuantity: Double,
    val unitCost: Double,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
