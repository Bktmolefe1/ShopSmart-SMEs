package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.CustomerDao
import com.example.data.local.dao.ExpenseDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.SaleDao
import com.example.data.local.dao.ShopSettingsDao
import com.example.data.local.dao.StockMovementDao
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.DebtPaymentEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SaleEntity
import com.example.data.local.entity.SaleItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.StockMovementEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CustomerEntity::class,
        SaleEntity::class,
        SaleItemEntity::class,
        DebtPaymentEntity::class,
        ExpenseEntity::class,
        StockMovementEntity::class,
        ShopSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun saleDao(): SaleDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun shopSettingsDao(): ShopSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shopsmart_bw.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate sample data asynchronously on first run
                            CoroutineScope(Dispatchers.IO).launch {
                                getInstance(context).populateInitialData()
                            }
                        }
                    })
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    suspend fun populateInitialData() {
        if (productDao().getAllProductsSync().isEmpty()) {
            productDao().insertProducts(SampleData.sampleProducts)
            customerDao().insertCustomers(SampleData.sampleCustomers)
            expenseDao().insertExpenses(SampleData.sampleExpenses)
            shopSettingsDao().insertOrUpdate(SampleData.initialSettings)

            // Also create an initial sample sale for realistic reporting
            val firstCustomer = SampleData.sampleCustomers[0]
            val saleId = saleDao().insertSale(
                SaleEntity(
                    id = 0,
                    receiptNumber = "SSBW-${System.currentTimeMillis().toString().takeLast(6)}",
                    subtotal = 88.50,
                    discountAmount = 3.50,
                    totalAmount = 85.00,
                    totalCostOfGoodsSold = 70.00,
                    amountPaid = 40.00,
                    creditAmount = 45.00,
                    paymentMethod = "SPLIT",
                    splitDetails = "Cash: P40.00, Credit: P45.00",
                    customerId = firstCustomer.id,
                    customerName = firstCustomer.name,
                    customerPhone = firstCustomer.phone,
                    timestamp = System.currentTimeMillis() - 3600000L * 3,
                    status = "COMPLETED",
                    notes = "Initial shop sample sale"
                )
            )

            saleDao().insertSaleItems(
                listOf(
                    SaleItemEntity(
                        id = 0,
                        saleId = saleId,
                        productId = 1,
                        productName = "White Star Super Maize Meal 5kg",
                        quantity = 1.0,
                        unit = "pcs",
                        unitCostPrice = 40.00,
                        unitSellingPrice = 49.50,
                        subtotal = 49.50
                    ),
                    SaleItemEntity(
                        id = 0,
                        saleId = saleId,
                        productId = 3,
                        productName = "Tastic Parboiled Rice 2kg",
                        quantity = 1.0,
                        unit = "pcs",
                        unitCostPrice = 30.00,
                        unitSellingPrice = 39.00,
                        subtotal = 39.00
                    )
                )
            )

            // Initial stock movement
            stockMovementDao().insertMovement(
                StockMovementEntity(
                    id = 0,
                    productId = 1,
                    productName = "White Star Super Maize Meal 5kg",
                    type = "SALE",
                    quantityChange = -1.0,
                    previousQuantity = 23.0,
                    newQuantity = 22.0,
                    unitCost = 40.00,
                    notes = "Sale receipt SSBW-${saleId}",
                    timestamp = System.currentTimeMillis() - 3600000L * 3
                )
            )
        }
    }
}
