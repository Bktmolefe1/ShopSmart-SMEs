package com.example.domain.model

import com.example.data.local.entity.ProductEntity

data class CartItem(
    val product: ProductEntity,
    val quantity: Double = 1.0,
    val unitPriceOverride: Double? = null,
    val discountPercent: Double = 0.0
) {
    val unitPrice: Double
        get() = unitPriceOverride ?: product.sellingPrice

    val grossSubtotal: Double
        get() = unitPrice * quantity

    val discountAmount: Double
        get() = grossSubtotal * (discountPercent / 100.0)

    val finalSubtotal: Double
        get() = (grossSubtotal - discountAmount).coerceAtLeast(0.0)

    val cogs: Double
        get() = product.buyingPrice * quantity
}
