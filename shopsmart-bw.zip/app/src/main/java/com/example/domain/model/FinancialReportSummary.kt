package com.example.domain.model

data class TopProductItem(
    val productName: String,
    val quantitySold: Double,
    val revenue: Double,
    val profit: Double
)

data class FinancialReportSummary(
    val salesRevenue: Double = 0.0,
    val cashReceived: Double = 0.0,
    val creditSales: Double = 0.0,
    val costOfGoodsSold: Double = 0.0,
    val grossProfit: Double = 0.0,
    val operatingExpenses: Double = 0.0,
    val netOperatingProfit: Double = 0.0,
    val totalOutstandingDebt: Double = 0.0,
    val totalStockValuationCost: Double = 0.0,
    val stockPurchasesCost: Double = 0.0,
    val debtRepaymentsCollected: Double = 0.0,
    val netCashFlow: Double = 0.0,
    val salesCount: Int = 0,
    val topProducts: List<TopProductItem> = emptyList()
)
